import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator 
} from "@/components/ui/dropdown-menu";
import { 
  ChartLine, 
  Search, 
  Bell, 
  Calendar, 
  ChevronDown, 
  User, 
  Settings, 
  LogOut,
  Sun,
  Moon
} from "lucide-react";
import CurrencySelector from "@/components/ui/currency-selector";
import { useCurrency } from "@/hooks/use-currency";

export default function Header() {
  const [location] = useLocation();
  const { selectedCurrency } = useCurrency();
  const [isDark, setIsDark] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const navigationItems = [
    { path: "/dashboard", label: "Dashboard" },
    { path: "/explore", label: "Explore" },
    { path: "/tools", label: "Tools" },
    { path: "/orders", label: "Orders" },
    { path: "/watchlist", label: "Watchlist" },
    { path: "/portfolio", label: "Portfolio" },
  ];

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle("dark");
  };

  const handleGoogleCalendar = () => {
    // This would integrate with Google Calendar API
    window.open("https://calendar.google.com", "_blank");
  };

  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Main Navigation */}
          <div className="flex items-center space-x-8">
            <Link href="/">
              <div className="flex items-center cursor-pointer">
                <ChartLine className="text-brand-blue text-2xl mr-2" />
                <span className="text-xl font-bold text-gray-900 dark:text-white">IPO Central</span>
              </div>
            </Link>
            
            <nav className="hidden md:flex space-x-6">
              {navigationItems.map((item) => (
                <Link key={item.path} href={item.path}>
                  <span className={`pb-4 font-medium text-sm transition-colors cursor-pointer ${
                    location === item.path
                      ? "text-brand-blue border-b-2 border-brand-blue"
                      : "text-gray-600 dark:text-gray-300 hover:text-brand-blue"
                  }`}>
                    {item.label}
                  </span>
                </Link>
              ))}
            </nav>
          </div>

          {/* Search and User Controls */}
          <div className="flex items-center space-x-4">
            {/* Currency Selector */}
            <CurrencySelector />

            {/* Search */}
            <div className="relative hidden sm:block">
              <Input
                type="text"
                placeholder="Search stocks, IPOs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64 pl-10 pr-4"
              />
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            </div>

            {/* Notifications */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="relative">
                  <Bell className="h-5 w-5" />
                  <Badge className="absolute -top-1 -right-1 bg-alert-amber text-white text-xs h-5 w-5 flex items-center justify-center rounded-full">
                    3
                  </Badge>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <div className="p-3 border-b border-gray-200 dark:border-gray-700">
                  <h3 className="font-semibold">Notifications</h3>
                </div>
                <div className="p-2">
                  <div className="p-3 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-alert-amber rounded-full mt-2"></div>
                      <div>
                        <div className="text-sm font-medium">IPO Alert</div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">
                          Rivian (RIVN) earnings today at 4:30 PM
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="p-3 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-gain-green rounded-full mt-2"></div>
                      <div>
                        <div className="text-sm font-medium">Price Alert</div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">
                          AAPL reached your target of $175
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Google Calendar Integration */}
            <Button 
              variant="default" 
              size="sm" 
              onClick={handleGoogleCalendar}
              className="bg-brand-blue hover:bg-blue-700 text-white"
            >
              <Calendar className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Calendar</span>
            </Button>

            {/* Theme Toggle */}
            <Button variant="ghost" size="sm" onClick={toggleTheme}>
              {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-brand-blue rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-medium">JD</span>
                  </div>
                  <span className="hidden sm:block text-sm font-medium">John Doe</span>
                  <ChevronDown className="h-4 w-4 text-gray-400" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}
