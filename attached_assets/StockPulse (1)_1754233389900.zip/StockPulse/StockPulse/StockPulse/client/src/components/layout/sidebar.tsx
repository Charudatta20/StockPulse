import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  TrendingDown, 
  Rocket, 
  BarChart3, 
  Newspaper, 
  Filter,
  Star
} from "lucide-react";
import { useCurrency } from "@/hooks/use-currency";
import { useWebSocket } from "@/hooks/use-websocket";

export default function Sidebar() {
  const [location] = useLocation();
  const { convertPrice, selectedCurrency } = useCurrency();
  const { lastMessage } = useWebSocket();

  const { data: marketOverview } = useQuery({
    queryKey: ["/api/market-overview"],
  });

  const { data: watchlist } = useQuery({
    queryKey: ["/api/user/watchlist"],
  });

  // Mock market data (would come from real API)
  const marketData = [
    { name: "S&P 500", value: "4,738.72", change: "+0.85%", positive: true },
    { name: "NASDAQ", value: "14,864.91", change: "-0.23%", positive: false },
    { name: "FTSE 100", value: "7,526.84", change: "+1.12%", positive: true },
  ];

  const quickLinks = [
    { icon: Rocket, label: "Upcoming IPOs", href: "/tools?tab=ipos" },
    { icon: TrendingUp, label: "Top Gainers", href: "/explore?filter=gainers" },
    { icon: Newspaper, label: "Market News", href: "/news" },
    { icon: Filter, label: "Stock Screener", href: "/tools?tab=screener" },
  ];

  // Mock watchlist data
  const watchlistPreview = [
    { symbol: "AAPL", name: "Apple Inc.", price: 175.84, change: 1.2, positive: true },
    { symbol: "TSLA", name: "Tesla Inc.", price: 248.91, change: -2.1, positive: false },
    { symbol: "MSFT", name: "Microsoft", price: 342.15, change: 0.8, positive: true },
  ];

  return (
    <aside className="w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex-shrink-0 overflow-y-auto custom-scrollbar">
      <div className="p-4 space-y-6">
        {/* Market Overview */}
        <div>
          <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Market Overview</h3>
          <div className="space-y-2">
            {marketData.map((market) => (
              <div key={market.name} className="flex justify-between items-center text-sm">
                <span className="text-gray-600 dark:text-gray-400">{market.name}</span>
                <div className="text-right">
                  <div className="font-medium">{market.value}</div>
                  <div className={`text-xs ${market.positive ? "text-gain-green" : "text-loss-red"}`}>
                    {market.change}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Quick Access</h3>
          <div className="space-y-2">
            {quickLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link key={link.href} href={link.href} className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400 hover:text-brand-blue p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                  <Icon className="w-4 h-4" />
                  <span>{link.label}</span>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Watchlist Preview */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300">My Watchlist</h3>
            <Link href="/watchlist" className="text-xs text-brand-blue hover:underline">
              View All
            </Link>
          </div>
          <div className="space-y-2">
            {watchlistPreview.map((stock) => (
              <div key={stock.symbol} className="flex justify-between items-center text-sm p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors">
                <div>
                  <div className="font-medium">{stock.symbol}</div>
                  <div className="text-xs text-gray-500">{stock.name}</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">
                    {convertPrice(stock.price, selectedCurrency)}
                  </div>
                  <div className={`text-xs ${stock.positive ? "text-gain-green" : "text-loss-red"}`}>
                    {stock.positive ? "+" : ""}{stock.change.toFixed(1)}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Market Status */}
        <Card>
          <CardContent className="p-4">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Market Status</h3>
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span>NYSE</span>
                <Badge className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 text-xs">
                  Open
                </Badge>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span>NASDAQ</span>
                <Badge className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 text-xs">
                  Open
                </Badge>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span>LSE</span>
                <Badge className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-300 text-xs">
                  Closed
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Live Updates Indicator */}
        {lastMessage && (
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-xs text-gray-600 dark:text-gray-400">Live Updates Active</span>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </aside>
  );
}
