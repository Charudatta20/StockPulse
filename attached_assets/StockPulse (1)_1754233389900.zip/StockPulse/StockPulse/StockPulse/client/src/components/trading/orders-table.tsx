import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useCurrency } from "@/hooks/use-currency";

interface OrdersTableProps {
  orders: any[];
  isLoading: boolean;
  onCancelOrder: (orderId: string) => void;
  getStatusColor: (status: string) => string;
  getStatusIcon: (status: string) => React.ReactNode;
}

export default function OrdersTable({ 
  orders, 
  isLoading, 
  onCancelOrder, 
  getStatusColor, 
  getStatusIcon 
}: OrdersTableProps) {
  const { convertPrice, selectedCurrency } = useCurrency();

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return {
      date: date.toLocaleDateString(),
      time: date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-16 bg-gray-100 dark:bg-gray-800 rounded-lg animate-pulse" />
        ))}
      </div>
    );
  }

  if (!orders || orders.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-gray-500 dark:text-gray-400 mb-2">No orders found</div>
        <div className="text-sm text-gray-400">Your trading history will appear here</div>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full table-responsive">
        <thead>
          <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200 dark:border-gray-700">
            <th className="pb-3">Stock</th>
            <th className="pb-3">Type</th>
            <th className="pb-3">Quantity</th>
            <th className="pb-3">Price</th>
            <th className="pb-3">Status</th>
            <th className="pb-3">Date/Time</th>
            <th className="pb-3">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
          {orders.map((order: any) => {
            const { date, time } = formatDateTime(order.createdAt);
            const canCancel = order.status === "pending";
            
            return (
              <tr key={order.id} className="text-sm hover:bg-gray-50 dark:hover:bg-gray-800">
                <td className="py-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                      <span className="text-xs font-bold">
                        {order.stock?.symbol || order.stockId}
                      </span>
                    </div>
                    <div>
                      <div className="font-medium">
                        {order.stock?.symbol || order.stockId}
                      </div>
                      <div className="text-xs text-gray-500">
                        {order.stock?.name || "Stock"}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="py-4">
                  <Badge 
                    variant="outline"
                    className={`${
                      order.type === "buy" 
                        ? "bg-gain-green/10 text-gain-green border-gain-green/20" 
                        : "bg-loss-red/10 text-loss-red border-loss-red/20"
                    }`}
                  >
                    {order.type.toUpperCase()}
                  </Badge>
                </td>
                <td className="py-4 font-medium">{order.quantity}</td>
                <td className="py-4">
                  <div>
                    <div className="font-medium">
                      {order.executedPrice 
                        ? convertPrice(parseFloat(order.executedPrice), selectedCurrency)
                        : order.price 
                          ? convertPrice(parseFloat(order.price), selectedCurrency)
                          : "Market"
                      }
                    </div>
                    <div className="text-xs text-gray-500 capitalize">
                      {order.orderType}
                    </div>
                  </div>
                </td>
                <td className="py-4">
                  <Badge className={getStatusColor(order.status)}>
                    <div className="flex items-center space-x-1">
                      {getStatusIcon(order.status)}
                      <span className="capitalize">{order.status}</span>
                    </div>
                  </Badge>
                </td>
                <td className="py-4 text-gray-500">
                  <div>{date}</div>
                  <div className="text-xs">{time}</div>
                </td>
                <td className="py-4">
                  {canCancel && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onCancelOrder(order.id)}
                      className="text-red-600 hover:text-red-700 border-red-200 hover:border-red-300"
                    >
                      Cancel
                    </Button>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
