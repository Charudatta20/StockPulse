import { Card } from "@/components/ui/card";
import { useCurrency } from "@/hooks/use-currency";

interface PortfolioChartProps {
  timeRange: string;
}

export default function PortfolioChart({ timeRange }: PortfolioChartProps) {
  const { convertPrice, selectedCurrency } = useCurrency();

  // Mock portfolio data (in real app, this would come from API)
  const portfolioValue = 127843.52;
  const dayChange = 3247.18;
  const dayChangePercent = 2.61;

  return (
    <div className="h-64 bg-gradient-to-r from-blue-50 to-green-50 dark:from-gray-800 dark:to-gray-700 rounded-lg p-4 relative chart-container">
      {/* Portfolio Value Display */}
      <div className="absolute bottom-4 left-4 z-10">
        <div className="text-2xl font-bold text-gray-900 dark:text-white">
          {convertPrice(portfolioValue, selectedCurrency)}
        </div>
        <div className="flex items-center text-gain-green">
          <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M5.293 9.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 7.414V15a1 1 0 11-2 0V7.414L6.707 9.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
          </svg>
          <span className="font-medium">
            +{convertPrice(dayChange, selectedCurrency)} ({dayChangePercent.toFixed(2)}%)
          </span>
        </div>
        <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          Past {timeRange}
        </div>
      </div>

      {/* Chart Placeholder */}
      <svg className="w-full h-full" viewBox="0 0 400 200">
        {/* Grid lines */}
        <defs>
          <pattern id="grid" width="40" height="20" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 20" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.1"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
        
        {/* Sample chart line showing upward trend */}
        <polyline 
          fill="none" 
          stroke="var(--gain-green)" 
          strokeWidth="3" 
          strokeLinecap="round"
          strokeLinejoin="round"
          points="20,150 60,140 100,130 140,110 180,115 220,95 260,100 300,80 340,85 380,70"
        />
        
        {/* Gradient fill under the line */}
        <defs>
          <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{stopColor: "var(--gain-green)", stopOpacity: 0.3}} />
            <stop offset="100%" style={{stopColor: "var(--gain-green)", stopOpacity: 0}} />
          </linearGradient>
        </defs>
        <polygon
          fill="url(#gradient)"
          points="20,150 60,140 100,130 140,110 180,115 220,95 260,100 300,80 340,85 380,70 380,200 20,200"
        />
        
        {/* Data points */}
        {[
          [20, 150], [60, 140], [100, 130], [140, 110], [180, 115], 
          [220, 95], [260, 100], [300, 80], [340, 85], [380, 70]
        ].map(([x, y], index) => (
          <circle
            key={index}
            cx={x}
            cy={y}
            r="3"
            fill="var(--gain-green)"
            className="opacity-0 hover:opacity-100 transition-opacity cursor-pointer"
          />
        ))}
      </svg>

      {/* Time range indicator */}
      <div className="absolute top-4 right-4 text-xs text-gray-500 dark:text-gray-400">
        {timeRange} Performance
      </div>
    </div>
  );
}
