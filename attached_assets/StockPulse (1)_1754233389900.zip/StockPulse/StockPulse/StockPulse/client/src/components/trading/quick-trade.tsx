import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useCurrency } from "@/hooks/use-currency";
import { queryClient } from "@/lib/queryClient";

interface QuickTradeProps {
  selectedStock?: any;
}

export default function QuickTrade({ selectedStock }: QuickTradeProps) {
  const { convertPrice, selectedCurrency } = useCurrency();
  const { toast } = useToast();
  
  const [symbol, setSymbol] = useState(selectedStock?.symbol || "");
  const [quantity, setQuantity] = useState("");
  const [orderType, setOrderType] = useState("market");
  const [limitPrice, setLimitPrice] = useState("");

  const createOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const response = await fetch("/api/user/orders", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "x-user-id": "demo-user" // In real app, this would come from auth
        },
        body: JSON.stringify(orderData),
      });
      if (!response.ok) throw new Error("Failed to create order");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/orders"] });
      toast({
        title: "Order Placed",
        description: "Your order has been successfully placed",
      });
      // Reset form
      setQuantity("");
      setLimitPrice("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to place order",
        variant: "destructive",
      });
    },
  });

  const handleTrade = (type: "buy" | "sell") => {
    if (!symbol || !quantity) {
      toast({
        title: "Missing Information",
        description: "Please enter symbol and quantity",
        variant: "destructive",
      });
      return;
    }

    const orderData = {
      stockId: selectedStock?.id || symbol,
      type,
      orderType,
      quantity: parseInt(quantity),
      price: orderType === "limit" ? parseFloat(limitPrice) : undefined,
      currency: selectedCurrency,
    };

    createOrderMutation.mutate(orderData);
  };

  const estimatedValue = selectedStock && quantity ? 
    parseFloat(selectedStock.currentPrice || "0") * parseInt(quantity || "0") : 0;

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Quick Trade</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {selectedStock && (
          <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-semibold">{selectedStock.symbol}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">{selectedStock.name}</div>
              </div>
              <div className="text-right">
                <div className="font-semibold">
                  {convertPrice(parseFloat(selectedStock.currentPrice || "0"), selectedCurrency)}
                </div>
                <div className={`text-sm flex items-center ${
                  parseFloat(selectedStock.dayChangePercent || "0") >= 0 
                    ? "text-gain-green" 
                    : "text-loss-red"
                }`}>
                  {parseFloat(selectedStock.dayChangePercent || "0") >= 0 ? (
                    <TrendingUp className="w-3 h-3 mr-1" />
                  ) : (
                    <TrendingDown className="w-3 h-3 mr-1" />
                  )}
                  {Math.abs(parseFloat(selectedStock.dayChangePercent || "0")).toFixed(2)}%
                </div>
              </div>
            </div>
          </div>
        )}

        <div>
          <Label htmlFor="symbol">Symbol</Label>
          <Input
            id="symbol"
            placeholder="AAPL"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            className="mt-1"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="quantity">Quantity</Label>
            <Input
              id="quantity"
              type="number"
              placeholder="100"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="orderType">Order Type</Label>
            <Select value={orderType} onValueChange={setOrderType}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="market">Market</SelectItem>
                <SelectItem value="limit">Limit</SelectItem>
                <SelectItem value="stop">Stop</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {orderType === "limit" && (
          <div>
            <Label htmlFor="limitPrice">Limit Price</Label>
            <Input
              id="limitPrice"
              type="number"
              step="0.01"
              placeholder="0.00"
              value={limitPrice}
              onChange={(e) => setLimitPrice(e.target.value)}
              className="mt-1"
            />
          </div>
        )}

        {estimatedValue > 0 && (
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <div className="text-sm text-gray-600 dark:text-gray-400">Estimated Value</div>
            <div className="text-lg font-semibold">
              {convertPrice(estimatedValue, selectedCurrency)}
            </div>
          </div>
        )}

        <div className="flex space-x-3">
          <Button 
            onClick={() => handleTrade("buy")}
            disabled={createOrderMutation.isPending}
            className="flex-1 bg-gain-green hover:bg-green-700 text-white"
          >
            {createOrderMutation.isPending ? "Processing..." : "Buy"}
          </Button>
          <Button 
            onClick={() => handleTrade("sell")}
            disabled={createOrderMutation.isPending}
            className="flex-1 bg-loss-red hover:bg-red-700 text-white"
          >
            {createOrderMutation.isPending ? "Processing..." : "Sell"}
          </Button>
        </div>

        <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
          Orders are executed during market hours. Current session: 
          <Badge variant="outline" className="ml-1">Market Open</Badge>
        </div>
      </CardContent>
    </Card>
  );
}
