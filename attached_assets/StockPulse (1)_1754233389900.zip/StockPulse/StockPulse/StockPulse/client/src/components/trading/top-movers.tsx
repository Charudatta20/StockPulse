import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Star } from "lucide-react";
import { useCurrency } from "@/hooks/use-currency";

export default function TopMovers() {
  const { convertPrice, selectedCurrency } = useCurrency();
  const [activeTab, setActiveTab] = useState("gainers");

  const { data: topMovers, isLoading } = useQuery({
    queryKey: ["/api/stocks/top-movers"],
  });

  const handleAddToWatchlist = (stockId: string) => {
    // This would add to watchlist via API
    console.log("Adding to watchlist:", stockId);
  };

  if (isLoading) {
    return (
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Top Movers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-100 dark:bg-gray-800 rounded-lg animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Filter and sort stocks based on active tab
  const filteredStocks = topMovers?.filter((stock: any) => {
    const changePercent = parseFloat(stock.dayChangePercent || "0");
    return activeTab === "gainers" ? changePercent > 0 : changePercent < 0;
  }).sort((a: any, b: any) => {
    const aChange = Math.abs(parseFloat(a.dayChangePercent || "0"));
    const bChange = Math.abs(parseFloat(b.dayChangePercent || "0"));
    return bChange - aChange;
  }).slice(0, 5) || [];

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-semibold">Top Movers</CardTitle>
          <div className="flex space-x-2">
            <Button
              size="sm"
              variant={activeTab === "gainers" ? "default" : "outline"}
              onClick={() => setActiveTab("gainers")}
              className={activeTab === "gainers" ? "bg-gain-green hover:bg-green-700" : ""}
            >
              Gainers
            </Button>
            <Button
              size="sm"
              variant={activeTab === "losers" ? "default" : "outline"}
              onClick={() => setActiveTab("losers")}
              className={activeTab === "losers" ? "bg-loss-red hover:bg-red-700" : ""}
            >
              Losers
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {filteredStocks.map((stock: any) => (
            <div key={stock.id} className="flex justify-between items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg transition-colors group">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center">
                  <span className="text-sm font-bold text-gray-600 dark:text-gray-300">
                    {stock.symbol}
                  </span>
                </div>
                <div>
                  <div className="font-medium text-sm">{stock.name}</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">
                    <Badge variant="outline" className="text-xs">
                      {stock.exchange}
                    </Badge>
                    {stock.sector && (
                      <span className="ml-2">{stock.sector}</span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <div className="font-medium">
                    {convertPrice(parseFloat(stock.currentPrice || "0"), selectedCurrency)}
                  </div>
                  <div className={`text-sm font-medium flex items-center ${
                    parseFloat(stock.dayChangePercent || "0") >= 0 
                      ? "text-gain-green" 
                      : "text-loss-red"
                  }`}>
                    {parseFloat(stock.dayChangePercent || "0") >= 0 ? (
                      <TrendingUp className="w-3 h-3 mr-1" />
                    ) : (
                      <TrendingDown className="w-3 h-3 mr-1" />
                    )}
                    {Math.abs(parseFloat(stock.dayChangePercent || "0")).toFixed(2)}%
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleAddToWatchlist(stock.id)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Star className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
          
          {filteredStocks.length === 0 && (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <TrendingUp className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <div>No {activeTab} found</div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
