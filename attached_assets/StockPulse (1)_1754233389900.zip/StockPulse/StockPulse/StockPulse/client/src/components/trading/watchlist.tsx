import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Star, StarOff, Search, Plus } from "lucide-react";
import { useCurrency } from "@/hooks/use-currency";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

export default function Watchlist() {
  const { convertPrice, selectedCurrency } = useCurrency();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");

  const { data: watchlist, isLoading } = useQuery({
    queryKey: ["/api/user/watchlist"],
  });

  const { data: stocks } = useQuery({
    queryKey: ["/api/stocks", { search: searchQuery }],
    enabled: searchQuery.length > 0,
  });

  const addToWatchlistMutation = useMutation({
    mutationFn: async (stockId: string) => {
      const response = await fetch("/api/user/watchlist", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "x-user-id": "demo-user"
        },
        body: JSON.stringify({ stockId }),
      });
      if (!response.ok) throw new Error("Failed to add to watchlist");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/watchlist"] });
      toast({
        title: "Added to Watchlist",
        description: "Stock has been added to your watchlist",
      });
      setSearchQuery("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add stock to watchlist",
        variant: "destructive",
      });
    },
  });

  const removeFromWatchlistMutation = useMutation({
    mutationFn: async (stockId: string) => {
      const response = await fetch(`/api/user/watchlist/${stockId}`, {
        method: "DELETE",
        headers: { "x-user-id": "demo-user" },
      });
      if (!response.ok) throw new Error("Failed to remove from watchlist");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/watchlist"] });
      toast({
        title: "Removed from Watchlist",
        description: "Stock has been removed from your watchlist",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove stock from watchlist",
        variant: "destructive",
      });
    },
  });

  const handleAddToWatchlist = (stockId: string) => {
    addToWatchlistMutation.mutate(stockId);
  };

  const handleRemoveFromWatchlist = (stockId: string) => {
    removeFromWatchlistMutation.mutate(stockId);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>My Watchlist</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-100 dark:bg-gray-800 rounded-lg animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Add to Watchlist */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Plus className="w-5 h-5" />
            <span>Add to Watchlist</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search stocks to add..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            {searchQuery && stocks && (
              <div className="max-h-60 overflow-y-auto space-y-2">
                {stocks.slice(0, 5).map((stock: any) => (
                  <div key={stock.id} className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                        <span className="text-sm font-bold">{stock.symbol}</span>
                      </div>
                      <div>
                        <div className="font-medium text-sm">{stock.name}</div>
                        <div className="text-xs text-gray-500">
                          <Badge variant="outline" className="text-xs">{stock.exchange}</Badge>
                        </div>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleAddToWatchlist(stock.id)}
                      disabled={addToWatchlistMutation.isPending}
                    >
                      <Star className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Watchlist */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>My Watchlist ({watchlist?.length || 0})</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {watchlist && watchlist.length > 0 ? (
            <div className="space-y-3">
              {watchlist.map((item: any) => (
                <div key={item.id} className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:shadow-md transition-shadow">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                      <span className="text-sm font-bold">{item.stock?.symbol}</span>
                    </div>
                    <div>
                      <div className="font-medium">{item.stock?.name}</div>
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <Badge variant="outline" className="text-xs">
                          {item.stock?.exchange}
                        </Badge>
                        {item.stock?.sector && (
                          <span>{item.stock.sector}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <div className="font-semibold">
                        {convertPrice(parseFloat(item.stock?.currentPrice || "0"), selectedCurrency)}
                      </div>
                      <div className={`text-sm font-medium flex items-center ${
                        parseFloat(item.stock?.dayChangePercent || "0") >= 0 
                          ? "text-gain-green" 
                          : "text-loss-red"
                      }`}>
                        {parseFloat(item.stock?.dayChangePercent || "0") >= 0 ? (
                          <TrendingUp className="w-3 h-3 mr-1" />
                        ) : (
                          <TrendingDown className="w-3 h-3 mr-1" />
                        )}
                        {Math.abs(parseFloat(item.stock?.dayChangePercent || "0")).toFixed(2)}%
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveFromWatchlist(item.stockId)}
                      disabled={removeFromWatchlistMutation.isPending}
                      className="text-red-600 hover:text-red-700"
                    >
                      <StarOff className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Star className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <div className="text-gray-600 dark:text-gray-400 mb-2">Your watchlist is empty</div>
              <div className="text-sm text-gray-500">Search and add stocks above to start tracking them</div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
