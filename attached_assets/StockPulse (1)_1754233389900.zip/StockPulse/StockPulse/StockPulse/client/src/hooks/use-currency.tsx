import { createContext, useContext, useState, ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";

interface CurrencyContextType {
  selectedCurrency: string;
  setSelectedCurrency: (currency: string) => void;
  convertPrice: (amount: number, toCurrency: string) => string;
  getCurrencySymbol: (currency: string) => string;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

const currencySymbols: Record<string, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  JPY: "¥",
  INR: "₹",
  CAD: "C$",
  AUD: "A$",
  CHF: "Fr",
  CNY: "¥",
  KRW: "₩",
};

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [selectedCurrency, setSelectedCurrency] = useState("USD");

  const { data: exchangeRates } = useQuery({
    queryKey: ["/api/currency/USD", selectedCurrency],
    enabled: selectedCurrency !== "USD",
  });

  const convertPrice = (amount: number, toCurrency: string): string => {
    if (!amount || amount === 0) return getCurrencySymbol(toCurrency) + "0.00";
    
    let convertedAmount = amount;
    
    // If converting to a different currency and we have exchange rates
    if (toCurrency !== "USD" && exchangeRates?.rate) {
      convertedAmount = amount * parseFloat(exchangeRates.rate);
    }
    
    const symbol = getCurrencySymbol(toCurrency);
    
    // Format based on currency
    if (toCurrency === "JPY" || toCurrency === "KRW") {
      // No decimal places for these currencies
      return symbol + Math.round(convertedAmount).toLocaleString();
    } else {
      return symbol + convertedAmount.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
    }
  };

  const getCurrencySymbol = (currency: string): string => {
    return currencySymbols[currency] || currency + " ";
  };

  return (
    <CurrencyContext.Provider value={{
      selectedCurrency,
      setSelectedCurrency,
      convertPrice,
      getCurrencySymbol
    }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
}
