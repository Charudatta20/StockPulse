import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useCurrency } from "@/hooks/use-currency";
import { CreditCard, Shield, Lock } from 'lucide-react';

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
const stripePromise = import.meta.env.VITE_STRIPE_PUBLIC_KEY 
  ? loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY)
  : Promise.resolve(null);

const CheckoutForm = ({ amount }: { amount: number }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    if (!stripe || !elements) {
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin + "/portfolio",
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Funds have been added to your account!",
      });
    }
    
    setIsProcessing(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
        <PaymentElement />
      </div>
      <Button 
        type="submit" 
        disabled={!stripe || isProcessing} 
        className="w-full bg-brand-blue hover:bg-blue-700"
        size="lg"
      >
        {isProcessing ? (
          <div className="flex items-center space-x-2">
            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
            <span>Processing...</span>
          </div>
        ) : (
          <div className="flex items-center space-x-2">
            <CreditCard className="w-4 h-4" />
            <span>Add Funds - ${amount.toFixed(2)}</span>
          </div>
        )}
      </Button>
    </form>
  );
};

export default function Checkout() {
  const { convertPrice, selectedCurrency } = useCurrency();
  const [clientSecret, setClientSecret] = useState("");
  const [amount, setAmount] = useState(1000); // Default $1000

  useEffect(() => {
    // Only create PaymentIntent if Stripe is available
    if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
      return;
    }
    
    // Create PaymentIntent as soon as the page loads
    apiRequest("POST", "/api/create-payment-intent", { amount })
      .then((res) => res.json())
      .then((data) => {
        if (data.clientSecret) {
          setClientSecret(data.clientSecret);
        }
      })
      .catch((error) => {
        console.error("Error creating payment intent:", error);
      });
  }, [amount]);

  const fundingOptions = [500, 1000, 2500, 5000, 10000];

  // If Stripe is not configured, show a message
  if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <Card className="w-full max-w-md">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <CreditCard className="w-12 h-12 mx-auto text-gray-400" />
              <h2 className="text-xl font-semibold">Payment Processing Unavailable</h2>
              <p className="text-gray-600 dark:text-gray-400">
                Payment processing is currently not configured. Please contact support to enable funding for your account.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <Card className="w-full max-w-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-center space-x-2">
              <div className="animate-spin w-6 h-6 border-4 border-brand-blue border-t-transparent rounded-full" />
              <span>Setting up secure payment...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Add Funds</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Securely add funds to your trading account
          </p>
        </div>

        {/* Security Badge */}
        <div className="flex items-center justify-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
          <div className="flex items-center space-x-1">
            <Shield className="w-4 h-4" />
            <span>256-bit SSL</span>
          </div>
          <div className="flex items-center space-x-1">
            <Lock className="w-4 h-4" />
            <span>Bank-level Security</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Amount Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select Amount</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                {fundingOptions.map((option) => (
                  <Button
                    key={option}
                    variant={amount === option ? "default" : "outline"}
                    onClick={() => setAmount(option)}
                    className="h-12"
                  >
                    {convertPrice(option, selectedCurrency)}
                  </Button>
                ))}
              </div>
              
              <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Processing Fee</span>
                  <span>Free</span>
                </div>
                <div className="flex items-center justify-between text-sm mt-2">
                  <span className="text-gray-600 dark:text-gray-400">You'll receive</span>
                  <span className="font-semibold">{convertPrice(amount, selectedCurrency)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Form */}
          <Card>
            <CardHeader>
              <CardTitle>Payment Details</CardTitle>
            </CardHeader>
            <CardContent>
              <Elements stripe={stripePromise} options={{ clientSecret }}>
                <CheckoutForm amount={amount} />
              </Elements>
            </CardContent>
          </Card>
        </div>

        {/* Benefits */}
        <Card>
          <CardContent className="p-6">
            <h3 className="font-semibold mb-4">Why fund your account?</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="w-12 h-12 bg-brand-blue/10 rounded-lg flex items-center justify-center mx-auto mb-2">
                  <CreditCard className="w-6 h-6 text-brand-blue" />
                </div>
                <div className="font-medium">Instant Trading</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Start trading immediately after funding
                </div>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                  <Shield className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <div className="font-medium">Secure</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Bank-level security and encryption
                </div>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                  <Lock className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
                <div className="font-medium">Protected</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  FDIC insured up to $250,000
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
