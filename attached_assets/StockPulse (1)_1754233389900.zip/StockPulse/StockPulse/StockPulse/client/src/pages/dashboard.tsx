import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TrendingUp, TrendingDown, Bell, Rocket, BarChart3, Calendar } from "lucide-react";
import PortfolioChart from "@/components/trading/portfolio-chart";
import TopMovers from "@/components/trading/top-movers";
import MarketNews from "@/components/trading/market-news";
import QuickTrade from "@/components/trading/quick-trade";
import { useCurrency } from "@/hooks/use-currency";
import { useWebSocket } from "@/hooks/use-websocket";
import { useState } from "react";

export default function Dashboard() {
  const { convertPrice, selectedCurrency } = useCurrency();
  const { lastMessage } = useWebSocket();
  const [timeRange, setTimeRange] = useState("1D");

  const { data: portfolio } = useQuery({
    queryKey: ["/api/user/portfolio"],
  });

  const { data: alerts } = useQuery({
    queryKey: ["/api/user/alerts"],
  });

  const { data: upcomingIpos } = useQuery({
    queryKey: ["/api/ipos", { upcoming: true }],
  });

  // Mock portfolio data for display
  const portfolioValue = 127843.52;
  const todaysPL = 1234.56;
  const totalPL = 3247.18;
  const totalInvested = 124596.34;

  return (
    <div className="space-y-6 p-6">
      {/* Tab Navigation */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 -mx-6 -mt-6 mb-6">
        <div className="px-6">
          <nav className="flex space-x-8">
            <Button variant="ghost" className="py-4 px-1 border-b-2 border-brand-blue text-brand-blue font-medium text-sm">
              Dashboard
            </Button>
            <Button variant="ghost" className="py-4 px-1 border-b-2 border-transparent text-gray-500 hover:text-gray-700 text-sm">
              Explore
            </Button>
            <Button variant="ghost" className="py-4 px-1 border-b-2 border-transparent text-gray-500 hover:text-gray-700 text-sm">
              Tools & Products
            </Button>
            <Button variant="ghost" className="py-4 px-1 border-b-2 border-transparent text-gray-500 hover:text-gray-700 text-sm">
              Trading
            </Button>
            <Button variant="ghost" className="py-4 px-1 border-b-2 border-transparent text-gray-500 hover:text-gray-700 text-sm">
              Orders
            </Button>
            <Button variant="ghost" className="py-4 px-1 border-b-2 border-transparent text-gray-500 hover:text-gray-700 text-sm">
              Portfolio
            </Button>
          </nav>
        </div>
      </div>

      {/* Dashboard Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Portfolio Summary */}
        <div className="lg:col-span-2">
          <Card className="shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg font-semibold">Portfolio Performance</CardTitle>
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1D">1D</SelectItem>
                  <SelectItem value="1W">1W</SelectItem>
                  <SelectItem value="1M">1M</SelectItem>
                  <SelectItem value="1Y">1Y</SelectItem>
                </SelectContent>
              </Select>
            </CardHeader>
            <CardContent>
              <PortfolioChart timeRange={timeRange} />
              
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="text-center">
                  <div className="text-sm text-gray-500 dark:text-gray-400">Total Invested</div>
                  <div className="text-lg font-semibold">
                    {convertPrice(totalInvested, selectedCurrency)}
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-gray-500 dark:text-gray-400">Today's P&L</div>
                  <div className="text-lg font-semibold text-gain-green flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    +{convertPrice(todaysPL, selectedCurrency)}
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-gray-500 dark:text-gray-400">Total P&L</div>
                  <div className="text-lg font-semibold text-gain-green flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    +{convertPrice(totalPL, selectedCurrency)}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Market Alerts & Calendar */}
        <div className="space-y-6">
          {/* Market Alerts */}
          <Card className="shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg font-semibold">Market Alerts</CardTitle>
              <Button variant="outline" size="sm" className="text-brand-blue">
                <Bell className="w-4 h-4 mr-1" />
                Add Alert
              </Button>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start space-x-3 p-3 bg-alert-amber/10 rounded-lg">
                <div className="w-2 h-2 bg-alert-amber rounded-full mt-2"></div>
                <div>
                  <div className="text-sm font-medium">IPO Alert</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">
                    Rivian (RIVN) earnings today at 4:30 PM
                  </div>
                </div>
              </div>
              <div className="flex items-start space-x-3 p-3 bg-gain-green/10 rounded-lg">
                <Rocket className="w-4 h-4 text-gain-green mt-1" />
                <div>
                  <div className="text-sm font-medium">IPO Launch</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">
                    Klarna IPO pricing tomorrow
                  </div>
                </div>
              </div>
              <div className="flex items-start space-x-3 p-3 bg-highlight-purple/10 rounded-lg">
                <Bell className="w-4 h-4 text-highlight-purple mt-1" />
                <div>
                  <div className="text-sm font-medium">Price Alert</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">
                    AAPL reached your target of $175
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Upcoming IPOs */}
          <Card className="shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg font-semibold">Upcoming IPOs</CardTitle>
              <Button variant="outline" size="sm">View All</Button>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg">
                <div>
                  <div className="font-medium text-sm">Stripe Inc.</div>
                  <div className="text-xs text-gray-500">Expected: Dec 15, 2024</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium">$85-95</div>
                  <div className="text-xs text-gray-500">Est. Price</div>
                </div>
              </div>
              <div className="flex justify-between items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg">
                <div>
                  <div className="font-medium text-sm">SpaceX</div>
                  <div className="text-xs text-gray-500">Expected: Q1 2025</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium">$120-140</div>
                  <div className="text-xs text-gray-500">Est. Price</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Top Movers & Market Data */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <TopMovers />
        <MarketNews />
      </div>

      {/* Trading Interface & Tools */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <QuickTrade />
        
        {/* Tools & Products */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Tools & Products</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 mb-6">
              <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
                <Calendar className="w-6 h-6 text-brand-blue mb-2" />
                <span className="text-sm font-medium">Events</span>
              </Button>
              <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
                <BarChart3 className="w-6 h-6 text-brand-blue mb-2" />
                <span className="text-sm font-medium">Screener</span>
              </Button>
              <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
                <Rocket className="w-6 h-6 text-brand-blue mb-2" />
                <span className="text-sm font-medium">IPOs</span>
              </Button>
              <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
                <TrendingUp className="w-6 h-6 text-brand-blue mb-2" />
                <span className="text-sm font-medium">Analytics</span>
              </Button>
            </div>
            
            <div>
              <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Most Traded Today</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="font-medium">AAPL</span>
                  <span className="text-gray-500">45.2M vol</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="font-medium">TSLA</span>
                  <span className="text-gray-500">38.7M vol</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="font-medium">NVDA</span>
                  <span className="text-gray-500">35.1M vol</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Methods */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Payment Methods</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
                    <span className="text-white text-xs font-bold">V</span>
                  </div>
                  <div>
                    <div className="text-sm font-medium">Visa ****1234</div>
                    <div className="text-xs text-gray-500">Expires 12/25</div>
                  </div>
                </div>
                <span className="text-xs bg-gain-green text-white px-2 py-1 rounded">Primary</span>
              </div>
            </div>
            
            <Button variant="outline" size="sm" className="w-full mb-4">
              Add Payment Method
            </Button>
            
            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="flex justify-between items-center mb-3">
                <span className="text-sm font-medium">Account Balance</span>
                <span className="text-lg font-semibold">
                  {convertPrice(12847.32, selectedCurrency)}
                </span>
              </div>
              <div className="flex space-x-2">
                <Button size="sm" className="flex-1 bg-brand-blue hover:bg-blue-700">
                  Add Funds
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  Withdraw
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
