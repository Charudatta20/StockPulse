import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, TrendingUp, TrendingDown, Globe } from "lucide-react";
import { useCurrency } from "@/hooks/use-currency";

export default function Explore() {
  const { convertPrice, selectedCurrency } = useCurrency();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedExchange, setSelectedExchange] = useState("all");
  const [selectedSector, setSelectedSector] = useState("all");

  const { data: stocks, isLoading } = useQuery({
    queryKey: ["/api/stocks", { exchange: selectedExchange === "all" ? undefined : selectedExchange }],
  });

  const { data: mostTraded } = useQuery({
    queryKey: ["/api/stocks/most-traded"],
  });

  const exchanges = [
    { value: "all", label: "All Exchanges" },
    { value: "NYSE", label: "NYSE" },
    { value: "NASDAQ", label: "NASDAQ" },
    { value: "LSE", label: "London Stock Exchange" },
    { value: "TSE", label: "Tokyo Stock Exchange" },
    { value: "BSE", label: "Bombay Stock Exchange" },
    { value: "NSE", label: "National Stock Exchange" },
  ];

  const sectors = [
    { value: "all", label: "All Sectors" },
    { value: "Technology", label: "Technology" },
    { value: "Healthcare", label: "Healthcare" },
    { value: "Financial Services", label: "Financial Services" },
    { value: "Consumer Discretionary", label: "Consumer Discretionary" },
    { value: "Communication Services", label: "Communication Services" },
    { value: "Industrials", label: "Industrials" },
    { value: "Energy", label: "Energy" },
  ];

  const filteredStocks = stocks?.filter((stock: any) => {
    const matchesSearch = stock.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         stock.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSector = selectedSector === "all" || stock.sector === selectedSector;
    return matchesSearch && matchesSector;
  }) || [];

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Explore Markets</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Discover stocks from global exchanges and find your next investment
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Globe className="w-5 h-5 text-gray-500" />
          <span className="text-sm text-gray-600 dark:text-gray-400">
            Global Markets • Real-time data
          </span>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search stocks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedExchange} onValueChange={setSelectedExchange}>
              <SelectTrigger>
                <SelectValue placeholder="Exchange" />
              </SelectTrigger>
              <SelectContent>
                {exchanges.map((exchange) => (
                  <SelectItem key={exchange.value} value={exchange.value}>
                    {exchange.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedSector} onValueChange={setSelectedSector}>
              <SelectTrigger>
                <SelectValue placeholder="Sector" />
              </SelectTrigger>
              <SelectContent>
                {sectors.map((sector) => (
                  <SelectItem key={sector.value} value={sector.value}>
                    {sector.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" className="w-full">
              <Filter className="w-4 h-4 mr-2" />
              More Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Most Traded Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5" />
            <span>Most Traded Today</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {mostTraded?.slice(0, 8).map((stock: any) => (
              <div
                key={stock.id}
                className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:shadow-md transition-shadow cursor-pointer"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                      <span className="text-xs font-bold">{stock.symbol}</span>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {stock.exchange}
                    </Badge>
                  </div>
                  <div className="text-xs text-gray-500">
                    {(stock.volume / 1000000).toFixed(1)}M vol
                  </div>
                </div>
                <div className="text-sm font-medium truncate">{stock.name}</div>
                <div className="flex items-center justify-between mt-2">
                  <span className="font-semibold">
                    {convertPrice(parseFloat(stock.currentPrice || "0"), selectedCurrency)}
                  </span>
                  <div className={`flex items-center text-xs font-medium ${
                    parseFloat(stock.dayChangePercent || "0") >= 0 
                      ? "text-gain-green" 
                      : "text-loss-red"
                  }`}>
                    {parseFloat(stock.dayChangePercent || "0") >= 0 ? (
                      <TrendingUp className="w-3 h-3 mr-1" />
                    ) : (
                      <TrendingDown className="w-3 h-3 mr-1" />
                    )}
                    {Math.abs(parseFloat(stock.dayChangePercent || "0")).toFixed(2)}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Stock List */}
      <Card>
        <CardHeader>
          <CardTitle>All Stocks ({filteredStocks.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(10)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-100 dark:bg-gray-800 rounded-lg animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {filteredStocks.map((stock: any) => (
                <div
                  key={stock.id}
                  className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:shadow-md transition-shadow cursor-pointer"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                      <span className="text-sm font-bold">{stock.symbol}</span>
                    </div>
                    <div>
                      <div className="font-medium">{stock.name}</div>
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <Badge variant="outline" className="text-xs">
                          {stock.exchange}
                        </Badge>
                        {stock.sector && (
                          <span>{stock.sector}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">
                      {convertPrice(parseFloat(stock.currentPrice || "0"), selectedCurrency)}
                    </div>
                    <div className={`text-sm font-medium ${
                      parseFloat(stock.dayChangePercent || "0") >= 0 
                        ? "text-gain-green" 
                        : "text-loss-red"
                    }`}>
                      {parseFloat(stock.dayChangePercent || "0") >= 0 ? "+" : ""}
                      {parseFloat(stock.dayChangePercent || "0").toFixed(2)}%
                    </div>
                  </div>
                </div>
              ))}
              
              {filteredStocks.length === 0 && (
                <div className="text-center py-12">
                  <div className="text-gray-500 dark:text-gray-400">
                    No stocks found matching your criteria
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
