import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TrendingUp, TrendingDown, DollarSign, PieChart, BarChart3 } from "lucide-react";
import { useCurrency } from "@/hooks/use-currency";
import PortfolioChart from "@/components/trading/portfolio-chart";

export default function Portfolio() {
  const { convertPrice, selectedCurrency } = useCurrency();
  const [timeRange, setTimeRange] = useState("1M");

  const { data: portfolio, isLoading } = useQuery({
    queryKey: ["/api/user/portfolio"],
  });

  // Mock portfolio calculations (would be calculated from real data)
  const portfolioStats = {
    totalValue: 127843.52,
    totalInvested: 124596.34,
    totalPL: 3247.18,
    todayPL: 1234.56,
    dayChangePercent: 0.97,
  };

  const holdings = [
    {
      symbol: "AAPL",
      name: "Apple Inc.",
      quantity: 50,
      avgPrice: 150.25,
      currentPrice: 175.84,
      marketValue: 8792.00,
      dayChange: 125.50,
      dayChangePercent: 1.45,
      totalReturn: 1279.50,
      totalReturnPercent: 17.05,
    },
    {
      symbol: "TSLA",
      name: "Tesla Inc.",
      quantity: 25,
      avgPrice: 220.15,
      currentPrice: 248.91,
      marketValue: 6222.75,
      dayChange: -52.25,
      dayChangePercent: -0.83,
      totalReturn: 719.00,
      totalReturnPercent: 13.06,
    },
    {
      symbol: "MSFT",
      name: "Microsoft Corporation",
      quantity: 30,
      avgPrice: 285.60,
      currentPrice: 342.15,
      marketValue: 10264.50,
      dayChange: 78.30,
      dayChangePercent: 0.77,
      totalReturn: 1696.50,
      totalReturnPercent: 19.83,
    },
  ];

  const sectorAllocation = [
    { sector: "Technology", percentage: 68.5, value: 87652.31 },
    { sector: "Healthcare", percentage: 15.2, value: 19432.02 },
    { sector: "Financial Services", percentage: 10.8, value: 13803.10 },
    { sector: "Consumer Discretionary", percentage: 5.5, value: 7031.39 },
  ];

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Portfolio</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Track your investments and performance
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1D">1 Day</SelectItem>
              <SelectItem value="1W">1 Week</SelectItem>
              <SelectItem value="1M">1 Month</SelectItem>
              <SelectItem value="3M">3 Months</SelectItem>
              <SelectItem value="1Y">1 Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Portfolio Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Total Value</div>
                <div className="text-2xl font-bold">
                  {convertPrice(portfolioStats.totalValue, selectedCurrency)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Total P&L</div>
                <div className="text-2xl font-bold text-gain-green">
                  +{convertPrice(portfolioStats.totalPL, selectedCurrency)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Today's P&L</div>
                <div className={`text-2xl font-bold ${
                  portfolioStats.dayChangePercent >= 0 ? "text-gain-green" : "text-loss-red"
                }`}>
                  {portfolioStats.dayChangePercent >= 0 ? "+" : ""}
                  {convertPrice(portfolioStats.todayPL, selectedCurrency)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center">
                <PieChart className="w-6 h-6 text-orange-600 dark:text-orange-400" />
              </div>
              <div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Day Change</div>
                <div className={`text-2xl font-bold flex items-center ${
                  portfolioStats.dayChangePercent >= 0 ? "text-gain-green" : "text-loss-red"
                }`}>
                  {portfolioStats.dayChangePercent >= 0 ? (
                    <TrendingUp className="w-5 h-5 mr-1" />
                  ) : (
                    <TrendingDown className="w-5 h-5 mr-1" />
                  )}
                  {Math.abs(portfolioStats.dayChangePercent).toFixed(2)}%
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Portfolio Chart and Allocation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Portfolio Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <PortfolioChart timeRange={timeRange} />
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Sector Allocation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sectorAllocation.map((sector, index) => (
                <div key={sector.sector} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ 
                        backgroundColor: [
                          'var(--brand-blue)',
                          'var(--gain-green)', 
                          'var(--alert-amber)',
                          'var(--highlight-purple)'
                        ][index] 
                      }}
                    />
                    <span className="text-sm font-medium">{sector.sector}</span>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold">{sector.percentage}%</div>
                    <div className="text-xs text-gray-500">
                      {convertPrice(sector.value, selectedCurrency)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Holdings Table */}
      <Card>
        <CardHeader>
          <CardTitle>Your Holdings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b border-gray-200 dark:border-gray-700">
                  <th className="pb-3">Symbol</th>
                  <th className="pb-3">Quantity</th>
                  <th className="pb-3">Avg Price</th>
                  <th className="pb-3">Current Price</th>
                  <th className="pb-3">Market Value</th>
                  <th className="pb-3">Day Change</th>
                  <th className="pb-3">Total Return</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                {holdings.map((holding) => (
                  <tr key={holding.symbol} className="text-sm">
                    <td className="py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                          <span className="text-xs font-bold">{holding.symbol}</span>
                        </div>
                        <div>
                          <div className="font-medium">{holding.symbol}</div>
                          <div className="text-gray-500 text-xs">{holding.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 font-medium">{holding.quantity}</td>
                    <td className="py-4">
                      {convertPrice(holding.avgPrice, selectedCurrency)}
                    </td>
                    <td className="py-4 font-medium">
                      {convertPrice(holding.currentPrice, selectedCurrency)}
                    </td>
                    <td className="py-4 font-semibold">
                      {convertPrice(holding.marketValue, selectedCurrency)}
                    </td>
                    <td className="py-4">
                      <div className={`font-medium ${
                        holding.dayChangePercent >= 0 ? "text-gain-green" : "text-loss-red"
                      }`}>
                        {holding.dayChangePercent >= 0 ? "+" : ""}
                        {convertPrice(holding.dayChange, selectedCurrency)}
                      </div>
                      <div className={`text-xs ${
                        holding.dayChangePercent >= 0 ? "text-gain-green" : "text-loss-red"
                      }`}>
                        ({holding.dayChangePercent >= 0 ? "+" : ""}{holding.dayChangePercent.toFixed(2)}%)
                      </div>
                    </td>
                    <td className="py-4">
                      <div className={`font-medium ${
                        holding.totalReturnPercent >= 0 ? "text-gain-green" : "text-loss-red"
                      }`}>
                        {holding.totalReturnPercent >= 0 ? "+" : ""}
                        {convertPrice(holding.totalReturn, selectedCurrency)}
                      </div>
                      <div className={`text-xs ${
                        holding.totalReturnPercent >= 0 ? "text-gain-green" : "text-loss-red"
                      }`}>
                        ({holding.totalReturnPercent >= 0 ? "+" : ""}{holding.totalReturnPercent.toFixed(2)}%)
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
