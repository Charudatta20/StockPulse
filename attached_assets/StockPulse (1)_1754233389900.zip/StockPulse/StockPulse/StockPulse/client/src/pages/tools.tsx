import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Filter, Rocket, BarChart3, TrendingUp, Clock, Users, DollarSign } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useCurrency } from "@/hooks/use-currency";

export default function Tools() {
  const { convertPrice, selectedCurrency } = useCurrency();
  const [activeTab, setActiveTab] = useState("events");

  const { data: upcomingIpos } = useQuery({
    queryKey: ["/api/ipos", { upcoming: true }],
  });

  const { data: events } = useQuery({
    queryKey: ["/api/events"],
  });

  const tabs = [
    { id: "events", label: "Events", icon: Calendar },
    { id: "screener", label: "Screener", icon: Filter },
    { id: "ipos", label: "IPOs", icon: Rocket },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
  ];

  const renderEventsTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                <Calendar className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <div className="text-sm text-gray-500">Today's Events</div>
                <div className="text-xl font-semibold">5</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <div className="text-sm text-gray-500">Earnings This Week</div>
                <div className="text-xl font-semibold">23</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                <Rocket className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <div className="text-sm text-gray-500">IPO Launches</div>
                <div className="text-xl font-semibold">3</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Upcoming Events</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              {
                company: "Apple Inc.",
                symbol: "AAPL",
                event: "Quarterly Earnings",
                date: "Jan 31, 2024",
                time: "4:30 PM EST",
                type: "earnings"
              },
              {
                company: "Microsoft Corp.",
                symbol: "MSFT",
                event: "Quarterly Earnings",
                date: "Feb 1, 2024",
                time: "After Market Close",
                type: "earnings"
              },
              {
                company: "Stripe Inc.",
                symbol: "STRIPE",
                event: "IPO Launch",
                date: "Feb 15, 2024",
                time: "Market Open",
                type: "ipo"
              },
            ].map((event, index) => (
              <div key={index} className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                    <span className="text-sm font-bold">{event.symbol}</span>
                  </div>
                  <div>
                    <div className="font-medium">{event.company}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">{event.event}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center space-x-2">
                    <Badge variant={event.type === "earnings" ? "default" : "secondary"}>
                      {event.type}
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    {event.date} • {event.time}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderScreenerTab = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Stock Screener</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium mb-2">Market Cap</label>
              <select className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-lg">
                <option>Any</option>
                <option>Large Cap ({'>'}$10B)</option>
                <option>Mid Cap ($2B-$10B)</option>
                <option>Small Cap ({'<'}$2B)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">P/E Ratio</label>
              <select className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-lg">
                <option>Any</option>
                <option>Low ({'<'}15)</option>
                <option>Moderate (15-25)</option>
                <option>High ({'>'}25)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Dividend Yield</label>
              <select className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-lg">
                <option>Any</option>
                <option>High ({'>'}4%)</option>
                <option>Moderate (2-4%)</option>
                <option>Low ({'<'}2%)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Sector</label>
              <select className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-lg">
                <option>All Sectors</option>
                <option>Technology</option>
                <option>Healthcare</option>
                <option>Financial Services</option>
                <option>Consumer Discretionary</option>
              </select>
            </div>
          </div>
          
          <Button className="w-full md:w-auto">
            <Filter className="w-4 h-4 mr-2" />
            Run Screener
          </Button>
          
          <div className="mt-6 text-center text-gray-500">
            Configure your filters and run the screener to find stocks matching your criteria
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderIposTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Clock className="w-5 h-5 text-blue-600" />
              <div>
                <div className="text-sm text-gray-500">This Month</div>
                <div className="text-xl font-semibold">8</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <DollarSign className="w-5 h-5 text-green-600" />
              <div>
                <div className="text-sm text-gray-500">Total Raised</div>
                <div className="text-xl font-semibold">$2.4B</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <TrendingUp className="w-5 h-5 text-purple-600" />
              <div>
                <div className="text-sm text-gray-500">Avg Performance</div>
                <div className="text-xl font-semibold">+12.3%</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Users className="w-5 h-5 text-orange-600" />
              <div>
                <div className="text-sm text-gray-500">Investors</div>
                <div className="text-xl font-semibold">145K</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Upcoming IPOs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              {
                company: "Stripe Inc.",
                symbol: "STRIPE",
                expectedDate: "Feb 15, 2024",
                priceRange: "$85-95",
                exchange: "NASDAQ",
                sector: "Financial Technology",
                status: "upcoming"
              },
              {
                company: "SpaceX",
                symbol: "SPACEX",
                expectedDate: "Q1 2025",
                priceRange: "$120-140",
                exchange: "NYSE",
                sector: "Aerospace",
                status: "upcoming"
              },
              {
                company: "Discord Inc.",
                symbol: "DISCORD",
                expectedDate: "Mar 2024",
                priceRange: "$45-55",
                exchange: "NASDAQ",
                sector: "Communication",
                status: "upcoming"
              },
            ].map((ipo, index) => (
              <div key={index} className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                    <Rocket className="w-6 h-6 text-gray-600 dark:text-gray-400" />
                  </div>
                  <div>
                    <div className="font-medium">{ipo.company}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      {ipo.sector} • {ipo.exchange}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">{ipo.priceRange}</div>
                  <div className="text-sm text-gray-500">{ipo.expectedDate}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderAnalyticsTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-600">+15.2%</div>
            <div className="text-sm text-gray-500">Market Performance</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">1,247</div>
            <div className="text-sm text-gray-500">Active Stocks</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">$2.4T</div>
            <div className="text-sm text-gray-500">Market Cap</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">68%</div>
            <div className="text-sm text-gray-500">Gainers vs Losers</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Market Analytics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 bg-gray-50 dark:bg-gray-800 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <div className="text-gray-500">Advanced analytics charts would be displayed here</div>
              <div className="text-sm text-gray-400 mt-1">Integration with charting library required</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Tools & Products</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Powerful tools to analyze markets, screen stocks, and track events
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="flex space-x-8">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                  activeTab === tab.id
                    ? "border-brand-blue text-brand-blue"
                    : "border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === "events" && renderEventsTab()}
      {activeTab === "screener" && renderScreenerTab()}
      {activeTab === "ipos" && renderIposTab()}
      {activeTab === "analytics" && renderAnalyticsTab()}
    </div>
  );
}
