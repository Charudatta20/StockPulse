import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Search, Star } from "lucide-react";
import { useCurrency } from "@/hooks/use-currency";
import { useToast } from "@/hooks/use-toast";
import QuickTrade from "@/components/trading/quick-trade";

export default function Trading() {
  const { convertPrice, selectedCurrency } = useCurrency();
  const { toast } = useToast();
  const [selectedStock, setSelectedStock] = useState(null);
  const [watchingStocks, setWatchingStocks] = useState<string[]>([]);

  const { data: stocks } = useQuery({
    queryKey: ["/api/stocks"],
  });

  const { data: watchlist } = useQuery({
    queryKey: ["/api/user/watchlist"],
  });

  const addToWatchlist = async (stockId: string) => {
    try {
      // API call would go here
      setWatchingStocks([...watchingStocks, stockId]);
      toast({
        title: "Added to Watchlist",
        description: "Stock has been added to your watchlist",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add stock to watchlist",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Trading Center</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Execute trades and manage your positions
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className="text-green-600 border-green-600">
            Markets Open
          </Badge>
          <div className="text-sm text-gray-500">
            NYSE: 9:30 AM - 4:00 PM EST
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Stock Search & List */}
        <div className="lg:col-span-2 space-y-6">
          {/* Search */}
          <Card>
            <CardContent className="p-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search stocks to trade..."
                  className="pl-10"
                />
              </div>
            </CardContent>
          </Card>

          {/* Stock List */}
          <Card>
            <CardHeader>
              <CardTitle>Available Stocks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {stocks?.slice(0, 10).map((stock: any) => (
                  <div
                    key={stock.id}
                    className={`flex items-center justify-between p-4 border rounded-lg cursor-pointer transition-colors ${
                      selectedStock?.id === stock.id
                        ? "border-brand-blue bg-blue-50 dark:bg-blue-900/20"
                        : "border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600"
                    }`}
                    onClick={() => setSelectedStock(stock)}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                        <span className="text-sm font-bold">{stock.symbol}</span>
                      </div>
                      <div>
                        <div className="font-medium">{stock.name}</div>
                        <div className="flex items-center space-x-2 text-sm text-gray-500">
                          <Badge variant="outline" className="text-xs">
                            {stock.exchange}
                          </Badge>
                          <span>{stock.sector}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="text-right">
                        <div className="font-semibold">
                          {convertPrice(parseFloat(stock.currentPrice || "0"), selectedCurrency)}
                        </div>
                        <div className={`text-sm font-medium ${
                          parseFloat(stock.dayChangePercent || "0") >= 0 
                            ? "text-gain-green" 
                            : "text-loss-red"
                        }`}>
                          {parseFloat(stock.dayChangePercent || "0") >= 0 ? (
                            <TrendingUp className="w-3 h-3 inline mr-1" />
                          ) : (
                            <TrendingDown className="w-3 h-3 inline mr-1" />
                          )}
                          {Math.abs(parseFloat(stock.dayChangePercent || "0")).toFixed(2)}%
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          addToWatchlist(stock.id);
                        }}
                        className={watchingStocks.includes(stock.id) ? "text-yellow-500" : ""}
                      >
                        <Star className={`w-4 h-4 ${watchingStocks.includes(stock.id) ? "fill-current" : ""}`} />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Trading Panel */}
        <div className="space-y-6">
          <QuickTrade selectedStock={selectedStock} />
          
          {/* Account Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Account Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Buying Power</span>
                <span className="font-semibold">{convertPrice(45230.15, selectedCurrency)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Day's P&L</span>
                <span className="font-semibold text-gain-green">+{convertPrice(1247.83, selectedCurrency)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Total P&L</span>
                <span className="font-semibold text-gain-green">+{convertPrice(8956.21, selectedCurrency)}</span>
              </div>
              <div className="pt-3 border-t border-gray-200 dark:border-gray-700">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Portfolio Value</span>
                  <span className="text-lg font-bold">{convertPrice(127843.52, selectedCurrency)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Market Status */}
          <Card>
            <CardHeader>
              <CardTitle>Market Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">NYSE</span>
                <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                  Open
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">NASDAQ</span>
                <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                  Open
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">LSE</span>
                <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">
                  Closed
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">TSE</span>
                <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">
                  Closed
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
