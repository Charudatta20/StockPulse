# Replit.md

## Overview

This is a comprehensive financial trading and investment platform built with modern web technologies. The application provides users with global stock market data including US (NASDAQ/NYSE) and Indian (NSE) markets, portfolio management, trading capabilities, IPO tracking, and market news integration. It features real-time market data updates, multi-currency support (USD/INR), payment processing, and various financial tools including stock screening and market alerts.

## Recent Changes (August 2025)

- **Global Market Expansion**: Added comprehensive Indian stock market support (NSE)
  - 15 major Indian stocks: RELIANCE, TCS, HDFCBANK, ICICIBANK, INFY, etc.
  - Realistic INR pricing with major companies like TCS (₹4,125.80), RELIANCE (₹2,847.35)
  - Mixed with US stocks for global portfolio coverage
- **Indian IPO Pipeline**: Added 4 upcoming Indian IPOs including Bharti Hexacom, Ola Electric, Swiggy, Hyundai Motor India
- **Multi-currency Real-time Updates**: WebSocket streaming now supports both USD and INR price updates
- **Fixed Application Issues**: Resolved all API routing conflicts, database initialization, and DOM warnings

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Routing**: Wouter library for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Real-time Updates**: WebSocket connection for live market data

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL database
- **Session Management**: Express sessions with PostgreSQL store
- **API Design**: RESTful API with real-time WebSocket endpoints
- **Build System**: ESBuild for server bundling, Vite for client bundling

### Data Storage Solutions
- **Primary Database**: PostgreSQL via Neon serverless platform
- **ORM**: Drizzle ORM for type-safe database interactions
- **Schema Management**: Centralized schema in `shared/schema.ts` with Zod validation
- **Migration System**: Drizzle Kit for database migrations

### Authentication and Authorization
- **Session-based Authentication**: Using Express sessions stored in PostgreSQL
- **User Management**: Custom user system with encrypted passwords
- **Authorization**: Middleware-based route protection with user context

### Key Data Models
- **Users**: Account management with currency preferences and Stripe integration
- **Stocks**: Market data with real-time price updates and exchange information
- **Orders**: Trading order management with status tracking
- **Portfolio**: User holdings and performance tracking
- **Watchlist**: User-curated stock monitoring lists
- **IPOs**: Initial Public Offering tracking and notifications
- **Market Alerts**: User-defined price and volume alerts
- **News**: Financial news aggregation and display

## External Dependencies

### Payment Processing
- **Stripe**: Payment processing for account funding and subscriptions
- **Integration**: Stripe Elements for secure payment forms
- **Features**: Customer management, subscription handling, and payment intent processing

### Market Data APIs
- **Stock API**: Alpha Vantage or similar for real-time stock prices and market data
- **Currency Exchange**: ExchangeRate-API for multi-currency support
- **News API**: NewsAPI for financial news aggregation

### Third-party Services
- **Google Calendar**: Integration for market event alerts and IPO notifications
- **WebSocket Server**: Real-time market data streaming to connected clients
- **Email Services**: For user notifications and alerts (configured via environment variables)

### Development and Hosting
- **Replit Integration**: Custom plugins for development environment
- **Environment Configuration**: Environment-based configuration for API keys and database connections
- **Error Handling**: Comprehensive error boundaries and logging systems