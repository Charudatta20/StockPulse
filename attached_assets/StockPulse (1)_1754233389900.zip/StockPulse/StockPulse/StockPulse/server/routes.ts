import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import WebSocket, { WebSocketServer } from "ws";
import Stripe from "stripe";
import { storage } from "./storage";
import { insertOrderSchema, insertWatchlistSchema, insertAlertSchema } from "@shared/schema";
import { stockApi } from "./services/stockApi";
import { currencyApi } from "./services/currencyApi";
import { newsApi } from "./services/newsApi";
import { googleCalendar } from "./services/googleCalendar";

// Initialize sample IPOs function
async function initializeSampleIpos() {
  const sampleIpos = [
    // US IPOs
    {
      companyName: "TechCorp AI",
      symbol: "TCAI",
      exchange: "NASDAQ",
      expectedDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      priceRangeLow: "15.00",
      priceRangeHigh: "18.00",
      sharesOffered: 10000000,
      sector: "Technology",
      description: "Leading artificial intelligence software company",
      status: "upcoming",
      currency: "USD",
    },
    {
      companyName: "Green Energy Solutions",
      symbol: "GES",
      exchange: "NYSE",
      expectedDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000), // 45 days from now
      priceRangeLow: "20.00",
      priceRangeHigh: "25.00",
      sharesOffered: 8000000,
      sector: "Energy",
      description: "Renewable energy infrastructure development",
      status: "upcoming",
      currency: "USD",
    },
    {
      companyName: "HealthTech Innovations",
      symbol: "HTI",
      exchange: "NASDAQ",
      expectedDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000), // 60 days from now
      priceRangeLow: "12.00",
      priceRangeHigh: "16.00",
      sharesOffered: 12000000,
      sector: "Healthcare",
      description: "Digital health monitoring and diagnostics",
      status: "upcoming",
      currency: "USD",
    },
    
    // Indian IPOs
    {
      companyName: "Bharti Hexacom Ltd.",
      symbol: "BHARTIHEX",
      exchange: "NSE",
      expectedDate: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000), // 25 days from now
      priceRangeLow: "570.00",
      priceRangeHigh: "600.00",
      sharesOffered: 2500000,
      sector: "Telecommunications",
      description: "Telecom services provider in Rajasthan and Northeast India",
      status: "upcoming",
      currency: "INR",
    },
    {
      companyName: "Ola Electric Mobility Ltd.",
      symbol: "OLAELEC",
      exchange: "NSE",
      expectedDate: new Date(Date.now() + 35 * 24 * 60 * 60 * 1000), // 35 days from now
      priceRangeLow: "76.00",
      priceRangeHigh: "85.00",
      sharesOffered: 15000000,
      sector: "Electric Vehicles",
      description: "Electric vehicle manufacturer and mobility solutions",
      status: "upcoming",
      currency: "INR",
    },
    {
      companyName: "Swiggy Ltd.",
      symbol: "SWIGGY",
      exchange: "NSE",
      expectedDate: new Date(Date.now() + 50 * 24 * 60 * 60 * 1000), // 50 days from now
      priceRangeLow: "371.00",
      priceRangeHigh: "390.00",
      sharesOffered: 12000000,
      sector: "Food Delivery",
      description: "Online food ordering and delivery platform",
      status: "upcoming",
      currency: "INR",
    },
    {
      companyName: "Hyundai Motor India Ltd.",
      symbol: "HMIL",
      exchange: "NSE",
      expectedDate: new Date(Date.now() + 65 * 24 * 60 * 60 * 1000), // 65 days from now
      priceRangeLow: "1865.00",
      priceRangeHigh: "1960.00",
      sharesOffered: 8500000,
      sector: "Automobile",
      description: "Automobile manufacturer and dealer network",
      status: "upcoming",
      currency: "INR",
    },
  ];

  for (const ipoData of sampleIpos) {
    try {
      await storage.createIpo(ipoData);
    } catch (error) {
      // Skip if IPO already exists
    }
  }
}

// Extend Request type to include user
interface AuthenticatedRequest extends Request {
  user: { id: string };
}

// Initialize Stripe only if API key is available
let stripe: Stripe | null = null;
if (process.env.STRIPE_SECRET_KEY) {
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2025-07-30.basil",
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication middleware (simplified for demo)
  const requireAuth = (req: AuthenticatedRequest, res: any, next: any) => {
    const userId = req.headers['x-user-id'] || 'demo-user';
    req.user = { id: userId as string };
    next();
  };

  // Market data endpoints
  app.get("/api/stocks", async (req, res) => {
    try {
      const { exchange, search } = req.query;
      let stocks;
      
      if (search) {
        stocks = await storage.searchStocks(search as string);
      } else if (exchange) {
        stocks = await storage.getStocksByExchange(exchange as string);
      } else {
        stocks = await storage.getAllStocks();
      }
      
      res.json(stocks);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/stocks/top-movers", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const topMovers = await storage.getTopMovers(limit);
      res.json(topMovers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/stocks/most-traded", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const mostTraded = await storage.getMostTraded(limit);
      res.json(mostTraded);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/stocks/:symbol", async (req, res) => {
    try {
      const stock = await storage.getStockBySymbol(req.params.symbol);
      if (!stock) {
        return res.status(404).json({ message: "Stock not found" });
      }
      res.json(stock);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // IPO endpoints
  app.get("/api/ipos", async (req, res) => {
    try {
      const { upcoming } = req.query;
      let ipos;
      
      if (upcoming === 'true') {
        ipos = await storage.getUpcomingIpos();
      } else {
        ipos = await storage.getAllIpos();
      }
      
      res.json(ipos);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Currency endpoints
  app.get("/api/currency/:base/:target", async (req, res) => {
    try {
      const { base, target } = req.params;
      const rate = await storage.getCurrencyRate(base, target);
      
      if (!rate) {
        // Fetch from external API if not in cache
        const externalRate = await currencyApi.getExchangeRate(base, target);
        if (externalRate) {
          const savedRate = await storage.updateCurrencyRate({
            baseCurrency: base,
            targetCurrency: target,
            rate: externalRate.toString(),
          });
          res.json(savedRate);
        } else {
          res.status(404).json({ message: "Currency rate not found" });
        }
      } else {
        res.json(rate);
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // News endpoints
  app.get("/api/news", async (req, res) => {
    try {
      const { symbols, limit } = req.query;
      let news;
      
      if (symbols) {
        const symbolArray = (symbols as string).split(',');
        news = await storage.getNewsByStockSymbols(symbolArray);
      } else {
        const newsLimit = parseInt(limit as string) || 20;
        news = await storage.getLatestNews(newsLimit);
      }
      
      res.json(news);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // User-specific endpoints
  app.get("/api/user/portfolio", requireAuth, async (req, res) => {
    try {
      const portfolio = await storage.getUserPortfolio(req.user.id);
      res.json(portfolio);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/user/watchlist", requireAuth, async (req, res) => {
    try {
      const watchlist = await storage.getUserWatchlist(req.user.id);
      res.json(watchlist);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/user/watchlist", requireAuth, async (req, res) => {
    try {
      const data = insertWatchlistSchema.parse(req.body);
      const item = await storage.addToWatchlist({
        ...data,
        userId: req.user.id,
      });
      res.json(item);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/user/watchlist/:stockId", requireAuth, async (req, res) => {
    try {
      await storage.removeFromWatchlist(req.user.id, req.params.stockId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/user/orders", requireAuth, async (req, res) => {
    try {
      const orders = await storage.getUserOrders(req.user.id);
      res.json(orders);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/user/orders", requireAuth, async (req, res) => {
    try {
      const data = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder({
        ...data,
        userId: req.user.id,
      });
      res.json(order);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/user/alerts", requireAuth, async (req, res) => {
    try {
      const alerts = await storage.getUserAlerts(req.user.id);
      res.json(alerts);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/user/alerts", requireAuth, async (req, res) => {
    try {
      const data = insertAlertSchema.parse(req.body);
      const alert = await storage.createAlert({
        ...data,
        userId: req.user.id,
      });
      
      // Create Google Calendar event if requested
      if (req.body.createCalendarEvent) {
        try {
          const eventId = await googleCalendar.createAlert(alert, req.user.id);
          if (eventId) {
            await storage.updateAlert(alert.id, { googleEventId: eventId });
          }
        } catch (calendarError) {
          console.error('Calendar integration error:', calendarError);
        }
      }
      
      res.json(alert);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Payment endpoints
  app.post("/api/create-payment-intent", requireAuth, async (req, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ 
          message: "Payment processing is not available. Stripe API key not configured." 
        });
      }
      
      const { amount, currency = 'usd' } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100),
        currency,
        metadata: { userId: req.user.id },
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Initialize sample data endpoint
  app.post("/api/admin/initialize-data", async (req, res) => {
    try {
      // Initialize sample stocks
      await stockApi.initializeSampleStocks();
      
      // Initialize sample news
      await newsApi.initializeSampleNews();
      
      // Initialize sample IPOs
      await initializeSampleIpos();
      
      // Update stock prices with realistic values
      await stockApi.updateRandomStockPrices(10);
      
      res.json({ message: "Sample data initialized successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Real-time data update endpoint
  app.post("/api/admin/update-stock-prices", async (req, res) => {
    try {
      // Update stock prices from external API
      const updatedStocks = await stockApi.updateAllStockPrices();
      
      // Broadcast updates via WebSocket
      if (wss) {
        const message = JSON.stringify({
          type: 'STOCK_PRICES_UPDATE',
          data: updatedStocks
        });
        
        wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(message);
          }
        });
      }
      
      res.json({ message: "Stock prices updated", count: updatedStocks.length });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');

    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'SUBSCRIBE_STOCKS') {
          // Handle stock subscription
          ws.send(JSON.stringify({
            type: 'SUBSCRIPTION_CONFIRMED',
            symbols: data.symbols
          }));
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  // Schedule periodic price updates
  setInterval(async () => {
    try {
      const updatedStocks = await stockApi.updateRandomStockPrices(5);
      
      if (updatedStocks && updatedStocks.length > 0) {
        const message = JSON.stringify({
          type: 'STOCK_PRICES_UPDATE',
          data: updatedStocks
        });
        
        wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(message);
          }
        });
      }
    } catch (error) {
      console.error('Scheduled price update error:', error);
    }
  }, 10000); // Update every 10 seconds

  return httpServer;
}
