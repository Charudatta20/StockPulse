class CurrencyApiService {
  private apiKey = process.env.EXCHANGE_RATES_API_KEY || process.env.CURRENCY_API_KEY || "";
  private baseUrl = "https://v6.exchangerate-api.com/v6";

  async getExchangeRate(base: string, target: string): Promise<number | null> {
    try {
      if (base === target) {
        return 1;
      }
      
      const response = await fetch(
        `${this.baseUrl}/${this.apiKey}/pair/${base}/${target}`
      );
      
      if (!response.ok) {
        throw new Error(`Currency API request failed: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.result === "success" && data.conversion_rate) {
        return data.conversion_rate;
      }
      
      return null;
    } catch (error) {
      console.error(`Error fetching exchange rate ${base}/${target}:`, error);
      return null;
    }
  }

  async getMultipleRates(base: string, targets: string[]): Promise<Record<string, number>> {
    try {
      const response = await fetch(
        `${this.baseUrl}/${this.apiKey}/latest/${base}`
      );
      
      if (!response.ok) {
        throw new Error(`Currency API request failed: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.result === "success" && data.conversion_rates) {
        const rates: Record<string, number> = {};
        
        targets.forEach(target => {
          if (data.conversion_rates[target]) {
            rates[target] = data.conversion_rates[target];
          }
        });
        
        return rates;
      }
      
      return {};
    } catch (error) {
      console.error(`Error fetching multiple rates for ${base}:`, error);
      return {};
    }
  }

  convertAmount(amount: number, rate: number): number {
    return Math.round((amount * rate) * 100) / 100;
  }

  async initializeCurrencyRates(): Promise<void> {
    try {
      const baseCurrencies = ["USD", "EUR", "GBP", "JPY", "INR"];
      const targetCurrencies = ["USD", "EUR", "GBP", "JPY", "INR", "CAD", "AUD", "CHF", "CNY"];
      
      for (const base of baseCurrencies) {
        const rates = await this.getMultipleRates(base, targetCurrencies);
        
        for (const [target, rate] of Object.entries(rates)) {
          if (base !== target) {
            // Store rate in database via storage
            console.log(`Initialized rate: ${base}/${target} = ${rate}`);
            // await storage.updateCurrencyRate({ baseCurrency: base, targetCurrency: target, rate: rate.toString() });
          }
        }
        
        // Wait between requests to respect rate limits
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
      
      console.log('Currency rates initialized');
    } catch (error) {
      console.error('Error initializing currency rates:', error);
    }
  }
}

export const currencyApi = new CurrencyApiService();
