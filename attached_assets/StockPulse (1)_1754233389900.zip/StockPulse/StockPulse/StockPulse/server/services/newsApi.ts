import { storage } from "../storage";
import type { InsertNews } from "@shared/schema";

class NewsApiService {
  private apiKey = process.env.NEWS_API_KEY || process.env.FINANCIAL_NEWS_API_KEY || "";

  async getMarketNews(limit = 20): Promise<any[]> {
    try {
      const response = await fetch(
        `https://newsapi.org/v2/everything?q=stock+market+finance&sortBy=publishedAt&pageSize=${limit}&apiKey=${this.apiKey}`
      );
      
      if (!response.ok) {
        throw new Error(`News API request failed: ${response.status}`);
      }
      
      const data = await response.json();
      return data.articles || [];
    } catch (error) {
      console.error('Error fetching market news:', error);
      return [];
    }
  }

  async getStockNews(symbols: string[], limit = 10): Promise<any[]> {
    try {
      const query = symbols.join(' OR ');
      const response = await fetch(
        `https://newsapi.org/v2/everything?q=${encodeURIComponent(query)}&sortBy=publishedAt&pageSize=${limit}&apiKey=${this.apiKey}`
      );
      
      if (!response.ok) {
        throw new Error(`News API request failed: ${response.status}`);
      }
      
      const data = await response.json();
      return data.articles || [];
    } catch (error) {
      console.error('Error fetching stock news:', error);
      return [];
    }
  }

  async updateNewsDatabase(): Promise<void> {
    try {
      const articles = await this.getMarketNews(50);
      
      for (const article of articles) {
        const newsData: InsertNews = {
          title: article.title,
          summary: article.description,
          url: article.url,
          source: article.source.name,
          publishedAt: new Date(article.publishedAt),
          imageUrl: article.urlToImage,
          stockSymbols: this.extractStockSymbols(article.title + ' ' + article.description),
        };
        
        try {
          await storage.createNews(newsData);
        } catch (error) {
          // Skip if news already exists
          if (error instanceof Error && !error.message.includes('duplicate')) {
            console.error('Error saving news article:', error);
          }
        }
      }
      
      console.log(`Updated ${articles.length} news articles`);
    } catch (error) {
      console.error('Error updating news database:', error);
    }
  }

  private extractStockSymbols(text: string): string[] {
    const symbols: string[] = [];
    const commonStocks = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA', 'NVDA', 'META', 'NFLX', 'AMD', 'CRM'];
    
    for (const symbol of commonStocks) {
      if (text.toUpperCase().includes(symbol)) {
        symbols.push(symbol);
      }
    }
    
    return symbols;
  }

  async initializeSampleNews(): Promise<void> {
    try {
      const sampleNews = [
        {
          title: "Tesla Stock Surges on Strong Q4 Delivery Numbers",
          summary: "Tesla reported record quarterly deliveries, beating analyst expectations and driving the stock higher in pre-market trading.",
          url: "https://example.com/tesla-news",
          source: "Bloomberg",
          publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
          stockSymbols: ["TSLA"],
          imageUrl: null,
        },
        {
          title: "Fed Signals Potential Rate Cuts in 2024",
          summary: "Federal Reserve Chairman hints at monetary policy shifts affecting markets across all sectors.",
          url: "https://example.com/fed-news",
          source: "Reuters",
          publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
          stockSymbols: [],
          imageUrl: null,
        },
        {
          title: "AI Stocks Rally as OpenAI Announces New Features",
          summary: "Technology sector sees gains following artificial intelligence developments, with NVIDIA leading the charge.",
          url: "https://example.com/ai-news",
          source: "MarketWatch",
          publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
          stockSymbols: ["NVDA", "MSFT", "GOOGL"],
          imageUrl: null,
        },
      ];
      
      for (const newsData of sampleNews) {
        try {
          await storage.createNews(newsData);
        } catch (error) {
          // Skip if news already exists
        }
      }
      
      console.log('Sample news initialized');
    } catch (error) {
      console.error('Error initializing sample news:', error);
    }
  }
}

export const newsApi = new NewsApiService();
