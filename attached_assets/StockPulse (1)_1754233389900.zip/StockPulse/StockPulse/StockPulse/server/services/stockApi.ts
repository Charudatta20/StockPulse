import { storage } from "../storage";
import type { Stock } from "@shared/schema";

class StockApiService {
  private apiKey = process.env.ALPHA_VANTAGE_API_KEY || process.env.STOCK_API_KEY || "";

  async getStockPrice(symbol: string): Promise<number | null> {
    try {
      // Use Alpha Vantage API or Yahoo Finance API
      const response = await fetch(
        `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${this.apiKey}`
      );
      
      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }
      
      const data = await response.json();
      const quote = data["Global Quote"];
      
      if (quote && quote["05. price"]) {
        return parseFloat(quote["05. price"]);
      }
      
      return null;
    } catch (error) {
      console.error(`Error fetching price for ${symbol}:`, error);
      return null;
    }
  }

  async getStockData(symbol: string): Promise<Partial<Stock> | null> {
    try {
      const response = await fetch(
        `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${this.apiKey}`
      );
      
      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }
      
      const data = await response.json();
      const quote = data["Global Quote"];
      
      if (!quote) {
        return null;
      }
      
      const currentPrice = parseFloat(quote["05. price"]);
      const change = parseFloat(quote["09. change"]);
      const changePercent = parseFloat(quote["10. change percent"].replace('%', ''));
      
      return {
        currentPrice: currentPrice.toString(),
        dayChange: change.toString(),
        dayChangePercent: changePercent.toString(),
        volume: parseInt(quote["06. volume"]) || 0,
        lastUpdated: new Date(),
      };
    } catch (error) {
      console.error(`Error fetching data for ${symbol}:`, error);
      return null;
    }
  }

  async updateStockPrice(symbol: string): Promise<Stock | null> {
    try {
      const stockData = await this.getStockData(symbol);
      if (!stockData) {
        return null;
      }
      
      const existingStock = await storage.getStockBySymbol(symbol);
      if (!existingStock) {
        return null;
      }
      
      const updatedStock = await storage.updateStock(existingStock.id, stockData);
      return updatedStock;
    } catch (error) {
      console.error(`Error updating price for ${symbol}:`, error);
      return null;
    }
  }

  async updateAllStockPrices(): Promise<Stock[]> {
    try {
      const stocks = await storage.getAllStocks();
      const updatedStocks: Stock[] = [];
      
      // Update in batches to avoid rate limiting
      const batchSize = 5;
      for (let i = 0; i < stocks.length; i += batchSize) {
        const batch = stocks.slice(i, i + batchSize);
        
        const promises = batch.map(async (stock) => {
          const updated = await this.updateStockPrice(stock.symbol);
          if (updated) {
            updatedStocks.push(updated);
          }
        });
        
        await Promise.all(promises);
        
        // Wait between batches to respect rate limits
        if (i + batchSize < stocks.length) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }
      
      return updatedStocks;
    } catch (error) {
      console.error('Error updating all stock prices:', error);
      return [];
    }
  }

  async updateRandomStockPrices(count = 5): Promise<Stock[]> {
    try {
      const allStocks = await storage.getAllStocks();
      if (allStocks.length === 0) {
        return [];
      }
      
      // Select random stocks
      const randomStocks = allStocks
        .sort(() => 0.5 - Math.random())
        .slice(0, count);
      
      const updatedStocks: Stock[] = [];
      
      for (const stock of randomStocks) {
        const updated = await this.updateStockPrice(stock.symbol);
        if (updated) {
          updatedStocks.push(updated);
        }
      }
      
      return updatedStocks;
    } catch (error) {
      console.error('Error updating random stock prices:', error);
      return [];
    }
  }

  async initializeSampleStocks(): Promise<void> {
    try {
      const sampleStocks = [
        // US Stocks
        { id: "AAPL", symbol: "AAPL", name: "Apple Inc.", exchange: "NASDAQ", sector: "Technology", currency: "USD" },
        { id: "MSFT", symbol: "MSFT", name: "Microsoft Corporation", exchange: "NASDAQ", sector: "Technology", currency: "USD" },
        { id: "GOOGL", symbol: "GOOGL", name: "Alphabet Inc.", exchange: "NASDAQ", sector: "Technology", currency: "USD" },
        { id: "AMZN", symbol: "AMZN", name: "Amazon.com Inc.", exchange: "NASDAQ", sector: "Consumer Discretionary", currency: "USD" },
        { id: "TSLA", symbol: "TSLA", name: "Tesla Inc.", exchange: "NASDAQ", sector: "Consumer Discretionary", currency: "USD" },
        { id: "NVDA", symbol: "NVDA", name: "NVIDIA Corporation", exchange: "NASDAQ", sector: "Technology", currency: "USD" },
        { id: "META", symbol: "META", name: "Meta Platforms Inc.", exchange: "NASDAQ", sector: "Technology", currency: "USD" },
        { id: "NFLX", symbol: "NFLX", name: "Netflix Inc.", exchange: "NASDAQ", sector: "Communication Services", currency: "USD" },
        { id: "AMD", symbol: "AMD", name: "Advanced Micro Devices Inc.", exchange: "NASDAQ", sector: "Technology", currency: "USD" },
        { id: "CRM", symbol: "CRM", name: "Salesforce Inc.", exchange: "NYSE", sector: "Technology", currency: "USD" },
        
        // Indian Stocks
        { id: "RELIANCE", symbol: "RELIANCE", name: "Reliance Industries Ltd.", exchange: "NSE", sector: "Oil & Gas", currency: "INR" },
        { id: "TCS", symbol: "TCS", name: "Tata Consultancy Services Ltd.", exchange: "NSE", sector: "Information Technology", currency: "INR" },
        { id: "HDFCBANK", symbol: "HDFCBANK", name: "HDFC Bank Ltd.", exchange: "NSE", sector: "Banking", currency: "INR" },
        { id: "ICICIBANK", symbol: "ICICIBANK", name: "ICICI Bank Ltd.", exchange: "NSE", sector: "Banking", currency: "INR" },
        { id: "INFY", symbol: "INFY", name: "Infosys Ltd.", exchange: "NSE", sector: "Information Technology", currency: "INR" },
        { id: "HINDUNILVR", symbol: "HINDUNILVR", name: "Hindustan Unilever Ltd.", exchange: "NSE", sector: "FMCG", currency: "INR" },
        { id: "ITC", symbol: "ITC", name: "ITC Ltd.", exchange: "NSE", sector: "FMCG", currency: "INR" },
        { id: "SBIN", symbol: "SBIN", name: "State Bank of India", exchange: "NSE", sector: "Banking", currency: "INR" },
        { id: "BHARTIARTL", symbol: "BHARTIARTL", name: "Bharti Airtel Ltd.", exchange: "NSE", sector: "Telecommunications", currency: "INR" },
        { id: "KOTAKBANK", symbol: "KOTAKBANK", name: "Kotak Mahindra Bank Ltd.", exchange: "NSE", sector: "Banking", currency: "INR" },
        { id: "LT", symbol: "LT", name: "Larsen & Toubro Ltd.", exchange: "NSE", sector: "Construction", currency: "INR" },
        { id: "HCLTECH", symbol: "HCLTECH", name: "HCL Technologies Ltd.", exchange: "NSE", sector: "Information Technology", currency: "INR" },
        { id: "WIPRO", symbol: "WIPRO", name: "Wipro Ltd.", exchange: "NSE", sector: "Information Technology", currency: "INR" },
        { id: "MARUTI", symbol: "MARUTI", name: "Maruti Suzuki India Ltd.", exchange: "NSE", sector: "Automobile", currency: "INR" },
        { id: "ASIANPAINT", symbol: "ASIANPAINT", name: "Asian Paints Ltd.", exchange: "NSE", sector: "Paints", currency: "INR" },
      ];
      
      for (const stockData of sampleStocks) {
        const existing = await storage.getStockBySymbol(stockData.symbol);
        if (!existing) {
          await storage.createStock({
            ...stockData,
            currentPrice: "0",
            dayChange: "0",
            dayChangePercent: "0",
            volume: 0,
          });
        }
      }
      
      console.log('Sample stocks initialized');
    } catch (error) {
      console.error('Error initializing sample stocks:', error);
    }
  }

  async updateRandomStockPrices(count: number = 10): Promise<Stock[]> {
    try {
      const stockPrices = [
        // US Stocks (USD)
        { symbol: "AAPL", price: 175.84, change: 1.2 },
        { symbol: "MSFT", price: 342.15, change: 0.8 },
        { symbol: "GOOGL", price: 138.92, change: -0.5 },
        { symbol: "AMZN", price: 151.94, change: 2.1 },
        { symbol: "TSLA", price: 248.91, change: -2.1 },
        { symbol: "NVDA", price: 489.33, change: 3.4 },
        { symbol: "META", price: 351.69, change: 1.8 },
        { symbol: "NFLX", price: 425.37, change: -1.3 },
        { symbol: "AMD", price: 121.47, change: 2.5 },
        { symbol: "CRM", price: 251.28, change: 0.9 },
        
        // Indian Stocks (INR)
        { symbol: "RELIANCE", price: 2847.35, change: 2.1 },
        { symbol: "TCS", price: 4125.80, change: 1.5 },
        { symbol: "HDFCBANK", price: 1635.25, change: -0.8 },
        { symbol: "ICICIBANK", price: 1124.70, change: 1.9 },
        { symbol: "INFY", price: 1789.95, change: -1.2 },
        { symbol: "HINDUNILVR", price: 2456.30, change: 0.7 },
        { symbol: "ITC", price: 462.85, change: 1.8 },
        { symbol: "SBIN", price: 825.40, change: 2.3 },
        { symbol: "BHARTIARTL", price: 1547.60, change: -0.5 },
        { symbol: "KOTAKBANK", price: 1754.90, change: 1.1 },
        { symbol: "LT", price: 3687.25, change: 2.7 },
        { symbol: "HCLTECH", price: 1456.35, change: -1.8 },
        { symbol: "WIPRO", price: 298.75, change: 0.9 },
        { symbol: "MARUTI", price: 11845.60, change: 1.4 },
        { symbol: "ASIANPAINT", price: 2934.80, change: -0.3 },
      ];

      const updatedStocks: Stock[] = [];
      for (const stockPrice of stockPrices) {
        const stock = await storage.getStockBySymbol(stockPrice.symbol);
        if (stock) {
          const volume = Math.floor(Math.random() * 5000000) + 1000000; // Random volume between 1M-6M
          const updatedStock = await storage.updateStock(stock.id, {
            currentPrice: stockPrice.price.toFixed(2),
            dayChange: stockPrice.change.toFixed(2),
            dayChangePercent: stockPrice.change.toFixed(2),
            volume: volume,
          });
          updatedStocks.push(updatedStock);
        }
      }
      
      console.log('Stock prices updated with realistic values');
      return updatedStocks;
    } catch (error) {
      console.error('Error updating stock prices:', error);
      return [];
    }
  }
}

export const stockApi = new StockApiService();
