import { 
  users, stocks, ipos, orders, portfolio, watchlist, marketAlerts, currencyRates, news,
  type User, type InsertUser, type Stock, type InsertStock, type Ipo, type InsertIpo,
  type Order, type InsertOrder, type Portfolio, type InsertPortfolio,
  type Watchlist, type InsertWatchlist, type MarketAlert, type InsertMarketAlert,
  type CurrencyRate, type InsertCurrencyRate, type News, type InsertNews
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, asc, gte, lte } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStripeInfo(id: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User>;
  
  // Stocks
  getStock(id: string): Promise<Stock | undefined>;
  getStockBySymbol(symbol: string): Promise<Stock | undefined>;
  getAllStocks(): Promise<Stock[]>;
  getStocksByExchange(exchange: string): Promise<Stock[]>;
  createStock(stock: InsertStock): Promise<Stock>;
  updateStock(id: string, updates: Partial<Stock>): Promise<Stock>;
  getTopMovers(limit?: number): Promise<Stock[]>;
  getMostTraded(limit?: number): Promise<Stock[]>;
  searchStocks(query: string): Promise<Stock[]>;
  
  // IPOs
  getIpo(id: string): Promise<Ipo | undefined>;
  getAllIpos(): Promise<Ipo[]>;
  getUpcomingIpos(): Promise<Ipo[]>;
  createIpo(ipo: InsertIpo): Promise<Ipo>;
  updateIpo(id: string, updates: Partial<Ipo>): Promise<Ipo>;
  
  // Orders
  getOrder(id: string): Promise<Order | undefined>;
  getUserOrders(userId: string): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: string, updates: Partial<Order>): Promise<Order>;
  getRecentOrders(userId: string, limit?: number): Promise<Order[]>;
  
  // Portfolio
  getUserPortfolio(userId: string): Promise<Portfolio[]>;
  getPortfolioItem(userId: string, stockId: string): Promise<Portfolio | undefined>;
  updatePortfolio(portfolio: InsertPortfolio): Promise<Portfolio>;
  deletePortfolioItem(id: string): Promise<void>;
  
  // Watchlist
  getUserWatchlist(userId: string): Promise<Watchlist[]>;
  addToWatchlist(watchlist: InsertWatchlist): Promise<Watchlist>;
  removeFromWatchlist(userId: string, stockId: string): Promise<void>;
  
  // Alerts
  getUserAlerts(userId: string): Promise<MarketAlert[]>;
  createAlert(alert: InsertMarketAlert): Promise<MarketAlert>;
  updateAlert(id: string, updates: Partial<MarketAlert>): Promise<MarketAlert>;
  deleteAlert(id: string): Promise<void>;
  
  // Currency
  getCurrencyRate(base: string, target: string): Promise<CurrencyRate | undefined>;
  updateCurrencyRate(rate: InsertCurrencyRate): Promise<CurrencyRate>;
  
  // News
  getLatestNews(limit?: number): Promise<News[]>;
  getNewsByStockSymbols(symbols: string[]): Promise<News[]>;
  createNews(news: InsertNews): Promise<News>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserStripeInfo(id: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ stripeCustomerId, stripeSubscriptionId })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Stocks
  async getStock(id: string): Promise<Stock | undefined> {
    const [stock] = await db.select().from(stocks).where(eq(stocks.id, id));
    return stock || undefined;
  }

  async getStockBySymbol(symbol: string): Promise<Stock | undefined> {
    const [stock] = await db.select().from(stocks).where(eq(stocks.symbol, symbol));
    return stock || undefined;
  }

  async getAllStocks(): Promise<Stock[]> {
    return await db.select().from(stocks).orderBy(asc(stocks.symbol));
  }

  async getStocksByExchange(exchange: string): Promise<Stock[]> {
    return await db.select().from(stocks).where(eq(stocks.exchange, exchange));
  }

  async createStock(stock: InsertStock): Promise<Stock> {
    const [newStock] = await db.insert(stocks).values(stock).returning();
    return newStock;
  }

  async updateStock(id: string, updates: Partial<Stock>): Promise<Stock> {
    const [stock] = await db
      .update(stocks)
      .set({ ...updates, lastUpdated: new Date() })
      .where(eq(stocks.id, id))
      .returning();
    return stock;
  }

  async getTopMovers(limit = 10): Promise<Stock[]> {
    return await db
      .select()
      .from(stocks)
      .orderBy(desc(stocks.dayChangePercent))
      .limit(limit);
  }

  async getMostTraded(limit = 10): Promise<Stock[]> {
    return await db
      .select()
      .from(stocks)
      .orderBy(desc(stocks.volume))
      .limit(limit);
  }

  async searchStocks(query: string): Promise<Stock[]> {
    return await db
      .select()
      .from(stocks)
      .where(
        sql`${stocks.symbol} ILIKE ${`%${query}%`} OR ${stocks.name} ILIKE ${`%${query}%`}`
      )
      .limit(20);
  }

  // IPOs
  async getIpo(id: string): Promise<Ipo | undefined> {
    const [ipo] = await db.select().from(ipos).where(eq(ipos.id, id));
    return ipo || undefined;
  }

  async getAllIpos(): Promise<Ipo[]> {
    return await db.select().from(ipos).orderBy(desc(ipos.expectedDate));
  }

  async getUpcomingIpos(): Promise<Ipo[]> {
    return await db
      .select()
      .from(ipos)
      .where(
        and(
          eq(ipos.status, "upcoming"),
          gte(ipos.expectedDate, new Date())
        )
      )
      .orderBy(asc(ipos.expectedDate));
  }

  async createIpo(ipo: InsertIpo): Promise<Ipo> {
    const [newIpo] = await db.insert(ipos).values(ipo).returning();
    return newIpo;
  }

  async updateIpo(id: string, updates: Partial<Ipo>): Promise<Ipo> {
    const [ipo] = await db
      .update(ipos)
      .set(updates)
      .where(eq(ipos.id, id))
      .returning();
    return ipo;
  }

  // Orders
  async getOrder(id: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order || undefined;
  }

  async getUserOrders(userId: string): Promise<Order[]> {
    return await db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    return newOrder;
  }

  async updateOrder(id: string, updates: Partial<Order>): Promise<Order> {
    const [order] = await db
      .update(orders)
      .set(updates)
      .where(eq(orders.id, id))
      .returning();
    return order;
  }

  async getRecentOrders(userId: string, limit = 10): Promise<Order[]> {
    return await db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt))
      .limit(limit);
  }

  // Portfolio
  async getUserPortfolio(userId: string): Promise<Portfolio[]> {
    return await db
      .select()
      .from(portfolio)
      .where(eq(portfolio.userId, userId))
      .orderBy(desc(portfolio.updatedAt));
  }

  async getPortfolioItem(userId: string, stockId: string): Promise<Portfolio | undefined> {
    const [item] = await db
      .select()
      .from(portfolio)
      .where(and(eq(portfolio.userId, userId), eq(portfolio.stockId, stockId)));
    return item || undefined;
  }

  async updatePortfolio(portfolioData: InsertPortfolio): Promise<Portfolio> {
    const existing = await this.getPortfolioItem(portfolioData.userId, portfolioData.stockId);
    
    if (existing) {
      const [updated] = await db
        .update(portfolio)
        .set({ ...portfolioData, updatedAt: new Date() })
        .where(eq(portfolio.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(portfolio).values(portfolioData).returning();
      return created;
    }
  }

  async deletePortfolioItem(id: string): Promise<void> {
    await db.delete(portfolio).where(eq(portfolio.id, id));
  }

  // Watchlist
  async getUserWatchlist(userId: string): Promise<Watchlist[]> {
    return await db
      .select()
      .from(watchlist)
      .where(eq(watchlist.userId, userId))
      .orderBy(desc(watchlist.addedAt));
  }

  async addToWatchlist(watchlistData: InsertWatchlist): Promise<Watchlist> {
    const [item] = await db.insert(watchlist).values(watchlistData).returning();
    return item;
  }

  async removeFromWatchlist(userId: string, stockId: string): Promise<void> {
    await db
      .delete(watchlist)
      .where(and(eq(watchlist.userId, userId), eq(watchlist.stockId, stockId)));
  }

  // Alerts
  async getUserAlerts(userId: string): Promise<MarketAlert[]> {
    return await db
      .select()
      .from(marketAlerts)
      .where(eq(marketAlerts.userId, userId))
      .orderBy(desc(marketAlerts.createdAt));
  }

  async createAlert(alert: InsertMarketAlert): Promise<MarketAlert> {
    const [newAlert] = await db.insert(marketAlerts).values(alert).returning();
    return newAlert;
  }

  async updateAlert(id: string, updates: Partial<MarketAlert>): Promise<MarketAlert> {
    const [alert] = await db
      .update(marketAlerts)
      .set(updates)
      .where(eq(marketAlerts.id, id))
      .returning();
    return alert;
  }

  async deleteAlert(id: string): Promise<void> {
    await db.delete(marketAlerts).where(eq(marketAlerts.id, id));
  }

  // Currency
  async getCurrencyRate(base: string, target: string): Promise<CurrencyRate | undefined> {
    const [rate] = await db
      .select()
      .from(currencyRates)
      .where(and(eq(currencyRates.baseCurrency, base), eq(currencyRates.targetCurrency, target)));
    return rate || undefined;
  }

  async updateCurrencyRate(rate: InsertCurrencyRate): Promise<CurrencyRate> {
    const existing = await this.getCurrencyRate(rate.baseCurrency, rate.targetCurrency);
    
    if (existing) {
      const [updated] = await db
        .update(currencyRates)
        .set({ ...rate, updatedAt: new Date() })
        .where(eq(currencyRates.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(currencyRates).values(rate).returning();
      return created;
    }
  }

  // News
  async getLatestNews(limit = 20): Promise<News[]> {
    return await db
      .select()
      .from(news)
      .orderBy(desc(news.publishedAt))
      .limit(limit);
  }

  async getNewsByStockSymbols(symbols: string[]): Promise<News[]> {
    return await db
      .select()
      .from(news)
      .where(sql`${news.stockSymbols} && ${symbols}`)
      .orderBy(desc(news.publishedAt))
      .limit(10);
  }

  async createNews(newsData: InsertNews): Promise<News> {
    const [newNews] = await db.insert(news).values(newsData).returning();
    return newNews;
  }
}

export const storage = new DatabaseStorage();
