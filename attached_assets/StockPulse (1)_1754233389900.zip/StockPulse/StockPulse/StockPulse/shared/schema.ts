import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, decimal, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  preferredCurrency: varchar("preferred_currency", { length: 3 }).default("USD"),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  accountBalance: decimal("account_balance", { precision: 12, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const stocks = pgTable("stocks", {
  id: varchar("id").primaryKey(),
  symbol: varchar("symbol", { length: 10 }).notNull().unique(),
  name: text("name").notNull(),
  exchange: varchar("exchange", { length: 10 }).notNull(),
  sector: text("sector"),
  marketCap: decimal("market_cap", { precision: 15, scale: 2 }),
  currentPrice: decimal("current_price", { precision: 10, scale: 4 }),
  dayChange: decimal("day_change", { precision: 8, scale: 4 }),
  dayChangePercent: decimal("day_change_percent", { precision: 6, scale: 4 }),
  volume: integer("volume"),
  currency: varchar("currency", { length: 3 }).default("USD"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const ipos = pgTable("ipos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyName: text("company_name").notNull(),
  symbol: varchar("symbol", { length: 10 }),
  exchange: varchar("exchange", { length: 10 }).notNull(),
  expectedDate: timestamp("expected_date"),
  priceRangeLow: decimal("price_range_low", { precision: 10, scale: 2 }),
  priceRangeHigh: decimal("price_range_high", { precision: 10, scale: 2 }),
  sharesOffered: integer("shares_offered"),
  sector: text("sector"),
  description: text("description"),
  status: varchar("status", { length: 20 }).default("upcoming"), // upcoming, active, completed
  currency: varchar("currency", { length: 3 }).default("USD"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  stockId: varchar("stock_id").notNull().references(() => stocks.id),
  type: varchar("type", { length: 10 }).notNull(), // buy, sell
  orderType: varchar("order_type", { length: 10 }).notNull(), // market, limit, stop
  quantity: integer("quantity").notNull(),
  price: decimal("price", { precision: 10, scale: 4 }),
  executedPrice: decimal("executed_price", { precision: 10, scale: 4 }),
  status: varchar("status", { length: 20 }).default("pending"), // pending, executed, cancelled
  currency: varchar("currency", { length: 3 }).default("USD"),
  createdAt: timestamp("created_at").defaultNow(),
  executedAt: timestamp("executed_at"),
});

export const portfolio = pgTable("portfolio", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  stockId: varchar("stock_id").notNull().references(() => stocks.id),
  quantity: integer("quantity").notNull(),
  averagePrice: decimal("average_price", { precision: 10, scale: 4 }).notNull(),
  currency: varchar("currency", { length: 3 }).default("USD"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const watchlist = pgTable("watchlist", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  stockId: varchar("stock_id").notNull().references(() => stocks.id),
  addedAt: timestamp("added_at").defaultNow(),
});

export const marketAlerts = pgTable("market_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  stockId: varchar("stock_id").references(() => stocks.id),
  ipoId: varchar("ipo_id").references(() => ipos.id),
  type: varchar("type", { length: 20 }).notNull(), // price_alert, ipo_alert, earnings_alert
  condition: jsonb("condition").notNull(), // {operator: ">=", value: 175, field: "price"}
  message: text("message").notNull(),
  isActive: boolean("is_active").default(true),
  googleEventId: text("google_event_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const currencyRates = pgTable("currency_rates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  baseCurrency: varchar("base_currency", { length: 3 }).notNull(),
  targetCurrency: varchar("target_currency", { length: 3 }).notNull(),
  rate: decimal("rate", { precision: 12, scale: 6 }).notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const news = pgTable("news", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  summary: text("summary"),
  url: text("url").notNull(),
  source: text("source").notNull(),
  publishedAt: timestamp("published_at").notNull(),
  stockSymbols: text("stock_symbols").array(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  orders: many(orders),
  portfolio: many(portfolio),
  watchlist: many(watchlist),
  alerts: many(marketAlerts),
}));

export const stocksRelations = relations(stocks, ({ many }) => ({
  orders: many(orders),
  portfolio: many(portfolio),
  watchlist: many(watchlist),
  alerts: many(marketAlerts),
}));

export const ordersRelations = relations(orders, ({ one }) => ({
  user: one(users, { fields: [orders.userId], references: [users.id] }),
  stock: one(stocks, { fields: [orders.stockId], references: [stocks.id] }),
}));

export const portfolioRelations = relations(portfolio, ({ one }) => ({
  user: one(users, { fields: [portfolio.userId], references: [users.id] }),
  stock: one(stocks, { fields: [portfolio.stockId], references: [stocks.id] }),
}));

export const watchlistRelations = relations(watchlist, ({ one }) => ({
  user: one(users, { fields: [watchlist.userId], references: [users.id] }),
  stock: one(stocks, { fields: [watchlist.stockId], references: [stocks.id] }),
}));

export const alertsRelations = relations(marketAlerts, ({ one }) => ({
  user: one(users, { fields: [marketAlerts.userId], references: [users.id] }),
  stock: one(stocks, { fields: [marketAlerts.stockId], references: [stocks.id] }),
  ipo: one(ipos, { fields: [marketAlerts.ipoId], references: [ipos.id] }),
}));

export const iposRelations = relations(ipos, ({ many }) => ({
  alerts: many(marketAlerts),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  stripeCustomerId: true,
  stripeSubscriptionId: true,
});

export const insertStockSchema = createInsertSchema(stocks).omit({
  lastUpdated: true,
});

export const insertIpoSchema = createInsertSchema(ipos).omit({
  id: true,
  createdAt: true,
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  executedAt: true,
  executedPrice: true,
});

export const insertPortfolioSchema = createInsertSchema(portfolio).omit({
  id: true,
  updatedAt: true,
});

export const insertWatchlistSchema = createInsertSchema(watchlist).omit({
  id: true,
  addedAt: true,
});

export const insertAlertSchema = createInsertSchema(marketAlerts).omit({
  id: true,
  createdAt: true,
  googleEventId: true,
});

export const insertCurrencyRateSchema = createInsertSchema(currencyRates).omit({
  id: true,
  updatedAt: true,
});

export const insertNewsSchema = createInsertSchema(news).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Stock = typeof stocks.$inferSelect;
export type InsertStock = z.infer<typeof insertStockSchema>;
export type Ipo = typeof ipos.$inferSelect;
export type InsertIpo = z.infer<typeof insertIpoSchema>;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Portfolio = typeof portfolio.$inferSelect;
export type InsertPortfolio = z.infer<typeof insertPortfolioSchema>;
export type Watchlist = typeof watchlist.$inferSelect;
export type InsertWatchlist = z.infer<typeof insertWatchlistSchema>;
export type MarketAlert = typeof marketAlerts.$inferSelect;
export type InsertMarketAlert = z.infer<typeof insertAlertSchema>;
export type CurrencyRate = typeof currencyRates.$inferSelect;
export type InsertCurrencyRate = z.infer<typeof insertCurrencyRateSchema>;
export type News = typeof news.$inferSelect;
export type InsertNews = z.infer<typeof insertNewsSchema>;
