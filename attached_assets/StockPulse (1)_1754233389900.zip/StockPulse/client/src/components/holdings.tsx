import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useCurrency } from "@/hooks/use-currency";
import type { Holding } from "@shared/schema";

export default function Holdings() {
  const { formatCurrency } = useCurrency();

  const { data: holdings = [], isLoading } = useQuery<Holding[]>({
    queryKey: ["/api/holdings"],
  });

  const getStockColor = (symbol: string) => {
    const colors = {
      'AAPL': 'bg-blue-500',
      'MSFT': 'bg-green-500',
      'GOOGL': 'bg-purple-500',
    };
    return colors[symbol as keyof typeof colors] || 'bg-gray-500';
  };

  if (isLoading) {
    return (
      <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Holdings</h3>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
            View All
          </Button>
        </div>
        
        <div className="space-y-3">
          {holdings.map((holding) => {
            const isPositive = parseFloat(holding.totalGainLoss) >= 0;
            
            return (
              <div key={holding.id} className="flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className={`w-8 h-8 ${getStockColor(holding.stockSymbol)} mr-3`}>
                    <AvatarFallback className="text-white text-xs font-bold">
                      {holding.stockSymbol}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium text-gray-900 dark:text-gray-100 text-sm">
                      {holding.stockSymbol}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      {holding.shares} shares
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-gray-900 dark:text-gray-100 text-sm">
                    {formatCurrency(parseFloat(holding.currentValue))}
                  </div>
                  <div className={`text-xs ${isPositive ? 'text-gain' : 'text-loss'}`}>
                    {isPositive ? '+' : ''}{parseFloat(holding.totalGainLossPercent).toFixed(1)}%
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
