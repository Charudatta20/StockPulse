import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import type { NewsArticle } from "@shared/schema";

export default function MarketNews() {
  const { data: news = [], isLoading } = useQuery<NewsArticle[]>({
    queryKey: ["/api/news"],
  });

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHours < 1) return "Just now";
    return `${diffHours} hours ago`;
  };

  if (isLoading) {
    return (
      <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="space-y-2">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Market News</h3>
        
        <div className="space-y-4">
          {news.map((article, index) => (
            <article
              key={article.id}
              className={`${index < news.length - 1 ? 'border-b border-gray-100 dark:border-dark-border pb-3' : 'pb-3'}`}
            >
              <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-1">
                {article.title}
              </h4>
              <p className="text-xs text-gray-600 dark:text-gray-400 mb-2 line-clamp-2">
                {article.summary}
              </p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {formatTimeAgo(article.publishedAt)}
                </span>
                <button className="text-xs text-primary hover:text-primary/80">
                  Read more
                </button>
              </div>
            </article>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
