import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { useCurrency } from "@/hooks/use-currency";
import { TrendingUp, TrendingDown, Wallet, Layers } from "lucide-react";
import type { Portfolio } from "@shared/schema";

export default function PortfolioSummary() {
  const { formatCurrency } = useCurrency();

  const { data: portfolio, isLoading } = useQuery<Portfolio>({
    queryKey: ["/api/portfolio"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!portfolio) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-red-500">Failed to load portfolio data</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isDayPositive = parseFloat(portfolio.dayChange) >= 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Portfolio</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                {formatCurrency(parseFloat(portfolio.totalValue))}
              </p>
            </div>
            <div className="p-3 bg-primary/10 rounded-full">
              <TrendingUp className="h-5 w-5 text-primary" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <span className={`text-sm font-medium ${isDayPositive ? 'text-gain' : 'text-loss'}`}>
              {isDayPositive ? '+' : ''}{parseFloat(portfolio.dayChangePercent).toFixed(2)}%
            </span>
            <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">Today</span>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Day's Gain/Loss</p>
              <p className={`text-2xl font-bold ${isDayPositive ? 'text-gain' : 'text-loss'}`}>
                {isDayPositive ? '+' : ''}{formatCurrency(parseFloat(portfolio.dayChange))}
              </p>
            </div>
            <div className={`p-3 rounded-full ${isDayPositive ? 'bg-gain/10' : 'bg-loss/10'}`}>
              {isDayPositive ? (
                <TrendingUp className="h-5 w-5 text-gain" />
              ) : (
                <TrendingDown className="h-5 w-5 text-loss" />
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Buying Power</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                {formatCurrency(parseFloat(portfolio.buyingPower))}
              </p>
            </div>
            <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-full">
              <Wallet className="h-5 w-5 text-green-600 dark:text-green-400" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Positions</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">23</p>
            </div>
            <div className="p-3 bg-blue-100 dark:bg-blue-900/20 rounded-full">
              <Layers className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
