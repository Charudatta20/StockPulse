import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useCurrency } from "@/hooks/use-currency";
import type { IPO } from "@shared/schema";

export default function RecentIPOs() {
  const { formatCurrency } = useCurrency();

  const { data: ipos = [], isLoading } = useQuery<IPO[]>({
    queryKey: ["/api/ipos"],
  });

  const getIPOColor = (symbol: string) => {
    const colors = {
      'ARM': 'bg-red-500',
      'KKVR': 'bg-blue-500',
      'INST': 'bg-green-500',
    };
    return colors[symbol as keyof typeof colors] || 'bg-gray-500';
  };

  if (isLoading) {
    return (
      <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Recent IPOs</h3>
        
        <div className="space-y-4">
          {ipos.map((ipo) => {
            const isPositive = parseFloat(ipo.change) >= 0;
            const ipoDate = new Date(ipo.ipoDate);
            
            return (
              <div
                key={ipo.id}
                className="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-bg rounded-lg"
              >
                <div className="flex items-center">
                  <Avatar className={`w-10 h-10 ${getIPOColor(ipo.symbol)} mr-3`}>
                    <AvatarFallback className="text-white text-sm font-bold">
                      {ipo.symbol}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium text-gray-900 dark:text-gray-100">{ipo.name}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      {ipoDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-gray-900 dark:text-gray-100">
                    {formatCurrency(parseFloat(ipo.price))}
                  </div>
                  <div className={`text-xs ${isPositive ? 'text-gain' : 'text-loss'}`}>
                    {isPositive ? '+' : ''}{parseFloat(ipo.changePercent).toFixed(1)}%
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <Button
          variant="outline"
          className="w-full mt-4 text-primary hover:text-primary/80 border-primary/20 hover:bg-primary/5"
        >
          View All IPOs
        </Button>
      </CardContent>
    </Card>
  );
}
