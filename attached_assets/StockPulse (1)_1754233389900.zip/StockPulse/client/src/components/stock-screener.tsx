import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useCurrency } from "@/hooks/use-currency";
import { Filter } from "lucide-react";
import type { Stock, StockScreenerFilters } from "@shared/schema";

export default function StockScreener() {
  const { formatCurrency } = useCurrency();
  const [filters, setFilters] = useState<StockScreenerFilters>({});

  const { data: stocks = [], isLoading } = useQuery<Stock[]>({
    queryKey: ["/api/stocks/screener", filters],
  });

  const updateFilter = (key: keyof StockScreenerFilters, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const getStockColor = (symbol: string) => {
    const colors = {
      'AAPL': 'bg-blue-500',
      'MSFT': 'bg-green-500',
      'GOOGL': 'bg-purple-500',
    };
    return colors[symbol as keyof typeof colors] || 'bg-gray-500';
  };

  if (isLoading) {
    return (
      <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Stock Screener</h3>
          <Button variant="outline" size="sm" className="text-primary hover:text-primary/80">
            <Filter className="h-4 w-4 mr-1" />
            Advanced Filters
          </Button>
        </div>

        {/* Filter Controls */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Select onValueChange={(value) => updateFilter('sector', value === 'all' ? undefined : value)}>
            <SelectTrigger>
              <SelectValue placeholder="All Sectors" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sectors</SelectItem>
              <SelectItem value="Technology">Technology</SelectItem>
              <SelectItem value="Healthcare">Healthcare</SelectItem>
              <SelectItem value="Finance">Finance</SelectItem>
            </SelectContent>
          </Select>

          <Select onValueChange={(value) => updateFilter('marketCap', value === 'all' ? undefined : value)}>
            <SelectTrigger>
              <SelectValue placeholder="Market Cap" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Market Caps</SelectItem>
              <SelectItem value="large">Large Cap (&gt;$10B)</SelectItem>
              <SelectItem value="mid">Mid Cap ($2-10B)</SelectItem>
              <SelectItem value="small">Small Cap (&lt;$2B)</SelectItem>
            </SelectContent>
          </Select>

          <Input
            type="number"
            placeholder="Min Price"
            onChange={(e) => updateFilter('minPrice', e.target.value ? Number(e.target.value) : undefined)}
          />

          <Input
            type="number"
            placeholder="Max Price"
            onChange={(e) => updateFilter('maxPrice', e.target.value ? Number(e.target.value) : undefined)}
          />
        </div>

        {/* Results Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-dark-border">
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">Symbol</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">Price</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">Change</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">Volume</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">Market Cap</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">P/E</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-600 dark:text-gray-400">Action</th>
              </tr>
            </thead>
            <tbody>
              {stocks.map((stock) => {
                const isPositive = parseFloat(stock.change) >= 0;
                return (
                  <tr
                    key={stock.symbol}
                    className="border-b border-gray-100 dark:border-dark-border hover:bg-gray-50 dark:hover:bg-dark-bg"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center">
                        <Avatar className={`w-8 h-8 ${getStockColor(stock.symbol)} mr-3`}>
                          <AvatarFallback className="text-white text-xs font-bold">
                            {stock.symbol}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium text-gray-900 dark:text-gray-100">{stock.symbol}</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">{stock.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-medium text-gray-900 dark:text-gray-100">
                      {formatCurrency(parseFloat(stock.price))}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`text-sm font-medium ${isPositive ? 'text-gain' : 'text-loss'}`}>
                        {isPositive ? '+' : ''}{stock.change} ({isPositive ? '+' : ''}{stock.changePercent}%)
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                      {(stock.volume / 1000000).toFixed(1)}M
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">{stock.marketCap}</td>
                    <td className="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">{stock.peRatio}</td>
                    <td className="py-3 px-4">
                      <Button size="sm" className="bg-primary text-white hover:bg-primary/80">
                        Trade
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
