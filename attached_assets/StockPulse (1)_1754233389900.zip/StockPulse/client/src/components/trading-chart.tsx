import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useCurrency } from "@/hooks/use-currency";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import type { Stock } from "@shared/schema";

const timeRanges = [
  { label: '1D', value: '1d' },
  { label: '1W', value: '1w' },
  { label: '1M', value: '1m' },
  { label: '1Y', value: '1y' },
];

// Mock chart data - in production, this would come from an API
const generateMockData = (range: string) => {
  const points = range === '1d' ? 24 : range === '1w' ? 7 : range === '1m' ? 30 : 365;
  const basePrice = 173.45;
  const data = [];
  
  for (let i = 0; i < points; i++) {
    const variance = (Math.random() - 0.5) * 10;
    const price = basePrice + variance;
    data.push({
      time: i,
      price: price,
      volume: Math.floor(Math.random() * 50000000),
    });
  }
  
  return data;
};

export default function TradingChart() {
  const [selectedRange, setSelectedRange] = useState('1d');
  const { formatCurrency } = useCurrency();

  const { data: stock } = useQuery<Stock>({
    queryKey: ["/api/stocks", "AAPL"],
  });

  const chartData = generateMockData(selectedRange);

  if (!stock) return null;

  const isPositive = parseFloat(stock.change) >= 0;

  return (
    <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              {stock.symbol} - {stock.name}
            </h3>
            <div className="flex items-center space-x-4 mt-2">
              <span className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                {formatCurrency(parseFloat(stock.price))}
              </span>
              <span className={`text-sm font-medium ${isPositive ? 'text-gain' : 'text-loss'}`}>
                {isPositive ? '+' : ''}{stock.change} ({isPositive ? '+' : ''}{stock.changePercent}%)
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="flex bg-gray-100 dark:bg-dark-bg rounded-lg p-1">
              {timeRanges.map((range) => (
                <Button
                  key={range.value}
                  variant={selectedRange === range.value ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setSelectedRange(range.value)}
                  className={`px-3 py-1 text-xs font-medium rounded-md ${
                    selectedRange === range.value
                      ? 'bg-primary text-white'
                      : 'text-gray-600 dark:text-gray-400 hover:bg-white dark:hover:bg-dark-surface'
                  }`}
                >
                  {range.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Chart */}
        <div className="h-80 mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="time" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickFormatter={(value) => `$${value.toFixed(0)}`}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
                formatter={(value: number) => [formatCurrency(value), 'Price']}
              />
              <Line 
                type="monotone" 
                dataKey="price" 
                stroke={isPositive ? 'hsl(var(--gain))' : 'hsl(var(--loss))'} 
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Technical Indicators */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-50 dark:bg-dark-bg p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">RSI (14)</span>
              <span className="text-sm font-medium text-orange-600">68.5</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-dark-border rounded-full h-2 mt-2">
              <div className="bg-orange-600 h-2 rounded-full" style={{ width: '68.5%' }}></div>
            </div>
          </div>
          
          <div className="bg-gray-50 dark:bg-dark-bg p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">MACD</span>
              <span className="text-sm font-medium text-gain">Bullish</span>
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              Signal: 1.23 | Histogram: 0.45
            </div>
          </div>
          
          <div className="bg-gray-50 dark:bg-dark-bg p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">MA (50)</span>
              <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
                {formatCurrency(168.92)}
              </span>
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">Price above MA</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
