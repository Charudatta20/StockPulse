import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCurrency } from "@/hooks/use-currency";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { InsertTrade } from "@shared/schema";

export default function TradingPanel() {
  const [tradeType, setTradeType] = useState<'buy' | 'sell'>('buy');
  const [symbol, setSymbol] = useState('AAPL');
  const [shares, setShares] = useState(10);
  const [orderType, setOrderType] = useState('market');
  const { formatCurrency } = useCurrency();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const tradeMutation = useMutation({
    mutationFn: async (trade: InsertTrade) => {
      const response = await apiRequest('POST', '/api/trades', trade);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Trade Executed",
        description: `Successfully ${tradeType === 'buy' ? 'bought' : 'sold'} ${shares} shares of ${symbol}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/portfolio'] });
      queryClient.invalidateQueries({ queryKey: ['/api/holdings'] });
    },
    onError: (error) => {
      toast({
        title: "Trade Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleTrade = () => {
    const price = '173.45'; // In production, get current market price
    const totalAmount = (parseFloat(price) * shares).toFixed(2);

    tradeMutation.mutate({
      stockSymbol: symbol,
      type: tradeType,
      shares,
      price,
      totalAmount,
      orderType,
    });
  };

  const estimatedCost = shares * 173.45; // Mock price

  return (
    <Card className="bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Quick Trade</h3>
        
        {/* Trade Type Toggle */}
        <div className="flex bg-gray-100 dark:bg-dark-bg rounded-lg p-1 mb-4">
          <Button
            variant={tradeType === 'buy' ? 'default' : 'ghost'}
            className={`flex-1 py-2 px-4 text-sm font-medium rounded-md ${
              tradeType === 'buy'
                ? 'bg-gain text-white hover:bg-gain/80'
                : 'text-gray-600 dark:text-gray-400 hover:bg-white dark:hover:bg-dark-surface'
            }`}
            onClick={() => setTradeType('buy')}
          >
            Buy
          </Button>
          <Button
            variant={tradeType === 'sell' ? 'default' : 'ghost'}
            className={`flex-1 py-2 px-4 text-sm font-medium rounded-md ${
              tradeType === 'sell'
                ? 'bg-loss text-white hover:bg-loss/80'
                : 'text-gray-600 dark:text-gray-400 hover:bg-white dark:hover:bg-dark-surface'
            }`}
            onClick={() => setTradeType('sell')}
          >
            Sell
          </Button>
        </div>

        {/* Stock Symbol */}
        <div className="mb-4">
          <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Symbol
          </Label>
          <Input
            value={symbol}
            onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            className="w-full"
            placeholder="Enter stock symbol"
          />
        </div>

        {/* Shares */}
        <div className="mb-4">
          <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Shares
          </Label>
          <Input
            type="number"
            value={shares}
            onChange={(e) => setShares(Number(e.target.value))}
            className="w-full"
            min="1"
          />
        </div>

        {/* Order Type */}
        <div className="mb-4">
          <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Order Type
          </Label>
          <Select value={orderType} onValueChange={setOrderType}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="market">Market Order</SelectItem>
              <SelectItem value="limit">Limit Order</SelectItem>
              <SelectItem value="stop">Stop Loss</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Estimated Cost */}
        <div className="bg-gray-50 dark:bg-dark-bg p-4 rounded-lg mb-4">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600 dark:text-gray-400">Estimated Cost:</span>
            <span className="font-medium text-gray-900 dark:text-gray-100">
              {formatCurrency(estimatedCost)}
            </span>
          </div>
        </div>

        {/* Trade Button */}
        <Button
          onClick={handleTrade}
          disabled={tradeMutation.isPending || !symbol || shares <= 0}
          className={`w-full font-medium py-3 transition-colors ${
            tradeType === 'buy'
              ? 'bg-gain hover:bg-gain/80 text-white'
              : 'bg-loss hover:bg-loss/80 text-white'
          }`}
        >
          {tradeMutation.isPending
            ? 'Processing...'
            : `${tradeType === 'buy' ? 'Buy' : 'Sell'} ${symbol}`
          }
        </Button>
      </CardContent>
    </Card>
  );
}
