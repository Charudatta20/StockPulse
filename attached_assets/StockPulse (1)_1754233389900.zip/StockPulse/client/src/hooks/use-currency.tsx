import { createContext, useContext, useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { Currency, ExchangeRates } from "@shared/schema";

interface CurrencyContextType {
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  formatCurrency: (amount: number) => string;
  convertCurrency: (amount: number, fromCurrency?: Currency) => number;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

const currencySymbols: Record<Currency, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  JPY: "¥",
  INR: "₹",
};

export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  const [currency, setCurrencyState] = useState<Currency>(() => {
    const stored = localStorage.getItem("currency");
    return (stored as Currency) || "USD";
  });

  const { data: exchangeRates } = useQuery<ExchangeRates>({
    queryKey: ["/api/exchange-rates"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  useEffect(() => {
    localStorage.setItem("currency", currency);
  }, [currency]);

  const setCurrency = (newCurrency: Currency) => {
    setCurrencyState(newCurrency);
  };

  const convertCurrency = (amount: number, fromCurrency: Currency = "USD"): number => {
    if (!exchangeRates) return amount;
    
    // Convert from the base currency to USD first if needed
    const usdAmount = fromCurrency === "USD" ? amount : amount / exchangeRates[fromCurrency];
    
    // Then convert from USD to target currency
    return currency === "USD" ? usdAmount : usdAmount * exchangeRates[currency];
  };

  const formatCurrency = (amount: number, fromCurrency: Currency = "USD"): string => {
    const convertedAmount = convertCurrency(amount, fromCurrency);
    const symbol = currencySymbols[currency];
    
    // Format based on currency
    if (currency === "JPY" || currency === "INR") {
      return `${symbol}${convertedAmount.toLocaleString("en-US", { 
        maximumFractionDigits: 0 
      })}`;
    } else {
      return `${symbol}${convertedAmount.toLocaleString("en-US", { 
        minimumFractionDigits: 2, 
        maximumFractionDigits: 2 
      })}`;
    }
  };

  return (
    <CurrencyContext.Provider value={{ 
      currency, 
      setCurrency, 
      formatCurrency, 
      convertCurrency 
    }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error("useCurrency must be used within a CurrencyProvider");
  }
  return context;
}
