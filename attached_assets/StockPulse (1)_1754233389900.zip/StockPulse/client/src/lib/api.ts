import { apiRequest } from "./queryClient";
import type { Stock, StockScreenerFilters, Portfolio, Holding, Trade, IPO, NewsArticle, InsertTrade } from "@shared/schema";

export const stocksApi = {
  getAll: async (): Promise<Stock[]> => {
    const response = await apiRequest("GET", "/api/stocks");
    return response.json();
  },

  getFiltered: async (filters: StockScreenerFilters): Promise<Stock[]> => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined) {
        params.append(key, value.toString());
      }
    });
    
    const response = await apiRequest("GET", `/api/stocks/screener?${params}`);
    return response.json();
  },

  getBySymbol: async (symbol: string): Promise<Stock> => {
    const response = await apiRequest("GET", `/api/stocks/${symbol}`);
    return response.json();
  },
};

export const portfolioApi = {
  get: async (): Promise<Portfolio> => {
    const response = await apiRequest("GET", "/api/portfolio");
    return response.json();
  },
};

export const holdingsApi = {
  getAll: async (): Promise<Holding[]> => {
    const response = await apiRequest("GET", "/api/holdings");
    return response.json();
  },
};

export const tradesApi = {
  create: async (trade: InsertTrade): Promise<Trade> => {
    const response = await apiRequest("POST", "/api/trades", trade);
    return response.json();
  },
};

export const iposApi = {
  getAll: async (): Promise<IPO[]> => {
    const response = await apiRequest("GET", "/api/ipos");
    return response.json();
  },
};

export const newsApi = {
  getAll: async (): Promise<NewsArticle[]> => {
    const response = await apiRequest("GET", "/api/news");
    return response.json();
  },
};
