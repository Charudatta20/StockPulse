import type { Currency } from "@shared/schema";

export const currencies: Array<{
  value: Currency;
  label: string;
  symbol: string;
}> = [
  { value: "USD", label: "USD ($)", symbol: "$" },
  { value: "EUR", label: "EUR (€)", symbol: "€" },
  { value: "GBP", label: "GBP (£)", symbol: "£" },
  { value: "JPY", label: "JPY (¥)", symbol: "¥" },
  { value: "INR", label: "INR (₹)", symbol: "₹" },
];

export function getCurrencySymbol(currency: Currency): string {
  const found = currencies.find(c => c.value === currency);
  return found?.symbol || "$";
}

export function formatCurrencyAmount(
  amount: number,
  currency: Currency,
  options?: Intl.NumberFormatOptions
): string {
  const symbol = getCurrencySymbol(currency);
  
  const defaultOptions: Intl.NumberFormatOptions = {
    minimumFractionDigits: currency === "JPY" || currency === "INR" ? 0 : 2,
    maximumFractionDigits: currency === "JPY" || currency === "INR" ? 0 : 2,
  };

  const formatOptions = { ...defaultOptions, ...options };
  const formattedAmount = amount.toLocaleString("en-US", formatOptions);
  
  return `${symbol}${formattedAmount}`;
}
