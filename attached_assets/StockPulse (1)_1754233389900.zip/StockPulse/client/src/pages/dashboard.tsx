import Header from "@/components/header";
import PortfolioSummary from "@/components/portfolio-summary";
import TradingChart from "@/components/trading-chart";
import StockScreener from "@/components/stock-screener";
import TradingPanel from "@/components/trading-panel";
import RecentIPOs from "@/components/recent-ipos";
import Holdings from "@/components/holdings";
import MarketNews from "@/components/market-news";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-dark-bg text-gray-900 dark:text-gray-100 transition-colors duration-300">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3 space-y-6">
            <PortfolioSummary />
            <TradingChart />
            <StockScreener />
          </div>
          
          <div className="lg:col-span-1 space-y-6">
            <TradingPanel />
            <RecentIPOs />
            <Holdings />
            <MarketNews />
          </div>
        </div>
      </div>
    </div>
  );
}
