# StockPulse - Comprehensive Financial Trading Platform

## Overview

StockPulse is a modern full-stack financial trading and investment platform that provides users with global stock market data, portfolio management, and trading capabilities. The application supports both US (NASDAQ/NYSE) and Indian (NSE) stock markets with real-time price updates via WebSocket connections. Users can track portfolios, execute trades, monitor IPOs, stay informed with market news, and screen stocks based on various financial criteria. The platform includes multi-currency support with real-time exchange rate conversions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
**Framework**: React with TypeScript using Vite as the build tool for fast development and optimized production builds. The application uses Wouter for lightweight client-side routing instead of React Router.

**UI Component Library**: Built on Shadcn/ui components which are powered by Radix UI primitives, providing accessible and customizable UI components with consistent design patterns.

**Styling System**: Tailwind CSS with custom CSS variables for theming, supporting both light and dark modes with financial-specific color schemes for gains (green) and losses (red).

**State Management**: TanStack Query (React Query) handles all server state management, caching, and data synchronization. The application uses React Context for theme and currency preferences.

**Real-time Features**: WebSocket connections provide live market data updates for stock prices across both USD and INR markets.

### Backend Architecture
**Runtime Environment**: Node.js with Express.js framework using TypeScript and ES modules for modern JavaScript features.

**API Design**: RESTful API architecture with dedicated endpoints for stocks, portfolios, trades, IPOs, and market data. WebSocket server handles real-time price streaming.

**Database Integration**: Drizzle ORM provides type-safe database interactions with PostgreSQL, using centralized schema definitions in the shared directory.

**Session Management**: Express sessions with PostgreSQL store for persistent user authentication without external auth providers.

**Build System**: ESBuild for server-side bundling and Vite for client-side builds, optimized for both development and production environments.

### Data Storage Solutions
**Primary Database**: PostgreSQL hosted on Neon serverless platform for scalable cloud database management.

**Schema Management**: Drizzle Kit handles database migrations with schema definitions in `shared/schema.ts` ensuring type safety across the application.

**Data Models**: Comprehensive schema including users, stocks, portfolios, holdings, trades, IPOs, orders, watchlists, market alerts, currency rates, and news articles.

**Validation**: Zod schema validation integrated with Drizzle for runtime type checking and data validation.

### Authentication and Authorization
**Session-based Authentication**: Custom user management system using Express sessions stored in PostgreSQL rather than JWT tokens.

**User Context**: Middleware-based route protection with user session context passed through the application.

**Password Security**: Encrypted password storage with secure session management for user authentication.

### Key Integrations
**Financial Data APIs**: Integration points for Alpha Vantage or similar stock market data providers for real-time stock prices and market information.

**Currency Exchange**: Real-time exchange rate APIs for multi-currency support (USD, EUR, GBP, JPY, INR).

**News Integration**: Financial news API integration for market news and stock-specific updates.

**Payment Processing**: Stripe integration for subscription-based features and premium services.

**Calendar Integration**: Google Calendar API integration for market alerts and event scheduling.

### Multi-Market Support
**Global Markets**: Comprehensive support for both US and Indian stock markets with realistic pricing and market data.

**Currency Handling**: Multi-currency real-time updates with automatic conversion between USD, EUR, GBP, JPY, and INR.

**Regional Features**: Indian IPO pipeline tracking and NSE-specific stock data alongside traditional US market features.

## External Dependencies

- **Database**: PostgreSQL via Neon serverless platform
- **UI Components**: Radix UI primitives and Shadcn/ui component library
- **Styling**: Tailwind CSS with PostCSS processing
- **Build Tools**: Vite for frontend builds, ESBuild for backend bundling
- **ORM**: Drizzle ORM with Drizzle Kit for migrations
- **Validation**: Zod for runtime type validation
- **Charts**: Recharts for financial data visualization
- **State Management**: TanStack Query for server state
- **Payment Processing**: Stripe for subscription management
- **Real-time Communication**: WebSocket (ws) for live market data
- **Financial APIs**: Alpha Vantage (or similar) for stock market data
- **Currency APIs**: ExchangeRate-API for real-time exchange rates
- **News APIs**: News API or financial news services
- **Calendar Integration**: Google Calendar API for alerts