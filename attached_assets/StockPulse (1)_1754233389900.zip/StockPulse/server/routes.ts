import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTradeSchema, type StockScreenerFilters, type Currency, type ExchangeRates } from "@shared/schema";
import { z } from "zod";

// Exchange rates API (in production, use a real service like Fixer.io or ExchangeRate-API)
const EXCHANGE_RATES: ExchangeRates = {
  USD: 1,
  EUR: 0.85,
  GBP: 0.73,
  JPY: 110.12,
  INR: 74.85
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all stocks
  app.get("/api/stocks", async (req, res) => {
    try {
      const stocks = await storage.getStocks();
      res.json(stocks);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stocks" });
    }
  });

  // Get filtered stocks (screener)
  app.get("/api/stocks/screener", async (req, res) => {
    try {
      const filters: StockScreenerFilters = {
        sector: req.query.sector as string,
        marketCap: req.query.marketCap as string,
        minPrice: req.query.minPrice ? Number(req.query.minPrice) : undefined,
        maxPrice: req.query.maxPrice ? Number(req.query.maxPrice) : undefined,
        minVolume: req.query.minVolume ? Number(req.query.minVolume) : undefined,
        sortBy: req.query.sortBy as string,
        sortOrder: req.query.sortOrder as 'asc' | 'desc',
      };

      const stocks = await storage.getFilteredStocks(filters);
      res.json(stocks);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch filtered stocks" });
    }
  });

  // Get single stock
  app.get("/api/stocks/:symbol", async (req, res) => {
    try {
      const stock = await storage.getStock(req.params.symbol);
      if (!stock) {
        return res.status(404).json({ error: "Stock not found" });
      }
      res.json(stock);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stock" });
    }
  });

  // Get portfolio for user (mock user ID for now)
  app.get("/api/portfolio", async (req, res) => {
    try {
      const userId = "mock-user-id"; // In production, get from auth
      let portfolio = await storage.getPortfolio(userId);
      
      if (!portfolio) {
        // Create default portfolio
        portfolio = await storage.createPortfolio({
          userId,
          totalValue: "124567.89",
          dayChange: "2912.45",
          dayChangePercent: "2.34",
          buyingPower: "15432.10",
          lastUpdated: new Date(),
        });
      }
      
      res.json(portfolio);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch portfolio" });
    }
  });

  // Get holdings for user
  app.get("/api/holdings", async (req, res) => {
    try {
      const userId = "mock-user-id";
      let holdings = await storage.getHoldings(userId);
      
      if (holdings.length === 0) {
        // Create sample holdings
        const sampleHoldings = [
          {
            userId,
            stockSymbol: 'AAPL',
            shares: 25,
            averagePrice: '170.00',
            currentValue: '4336.25',
            totalGainLoss: '86.25',
            totalGainLossPercent: '2.1',
          },
          {
            userId,
            stockSymbol: 'MSFT',
            shares: 15,
            averagePrice: '415.00',
            currentValue: '6191.70',
            totalGainLoss: '-33.30',
            totalGainLossPercent: '-0.8',
          },
          {
            userId,
            stockSymbol: 'GOOGL',
            shares: 8,
            averagePrice: '175.00',
            currentValue: '1431.36',
            totalGainLoss: '31.36',
            totalGainLossPercent: '3.2',
          }
        ];

        for (const holding of sampleHoldings) {
          await storage.createHolding(holding);
        }
        holdings = await storage.getHoldings(userId);
      }
      
      res.json(holdings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch holdings" });
    }
  });

  // Execute trade
  app.post("/api/trades", async (req, res) => {
    try {
      const tradeData = insertTradeSchema.parse(req.body);
      const userId = "mock-user-id"; // In production, get from auth
      
      const trade = await storage.createTrade({
        ...tradeData,
        userId,
      });

      // Update holdings based on trade
      const existingHolding = await storage.getHolding(userId, trade.stockSymbol);
      
      if (trade.type === 'buy') {
        if (existingHolding) {
          const newShares = existingHolding.shares + trade.shares;
          const newAveragePrice = ((existingHolding.shares * parseFloat(existingHolding.averagePrice)) + 
                                 (trade.shares * parseFloat(trade.price))) / newShares;
          const currentStock = await storage.getStock(trade.stockSymbol);
          const currentValue = currentStock ? (newShares * parseFloat(currentStock.price)).toString() : "0";
          
          await storage.updateHolding(userId, trade.stockSymbol, {
            shares: newShares,
            averagePrice: newAveragePrice.toFixed(2),
            currentValue,
          });
        } else {
          const currentStock = await storage.getStock(trade.stockSymbol);
          const currentValue = currentStock ? (trade.shares * parseFloat(currentStock.price)).toString() : "0";
          
          await storage.createHolding({
            userId,
            stockSymbol: trade.stockSymbol,
            shares: trade.shares,
            averagePrice: trade.price,
            currentValue,
            totalGainLoss: "0",
            totalGainLossPercent: "0",
          });
        }
      } else if (trade.type === 'sell' && existingHolding) {
        const newShares = existingHolding.shares - trade.shares;
        if (newShares <= 0) {
          await storage.deleteHolding(userId, trade.stockSymbol);
        } else {
          const currentStock = await storage.getStock(trade.stockSymbol);
          const currentValue = currentStock ? (newShares * parseFloat(currentStock.price)).toString() : "0";
          
          await storage.updateHolding(userId, trade.stockSymbol, {
            shares: newShares,
            currentValue,
          });
        }
      }

      res.json(trade);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to execute trade" });
    }
  });

  // Get IPOs
  app.get("/api/ipos", async (req, res) => {
    try {
      const ipos = await storage.getIPOs();
      res.json(ipos);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch IPOs" });
    }
  });

  // Get news
  app.get("/api/news", async (req, res) => {
    try {
      const news = await storage.getNews();
      res.json(news);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch news" });
    }
  });

  // Get exchange rates
  app.get("/api/exchange-rates", async (req, res) => {
    try {
      res.json(EXCHANGE_RATES);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch exchange rates" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
