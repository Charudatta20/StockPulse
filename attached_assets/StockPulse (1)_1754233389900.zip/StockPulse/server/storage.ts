import { type User, type InsertUser, type Stock, type InsertStock, type Portfolio, type InsertPortfolio, type Holding, type InsertHolding, type Trade, type InsertTrade, type IPO, type InsertIPO, type NewsArticle, type InsertNewsArticle, type StockScreenerFilters } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Stock methods
  getStocks(): Promise<Stock[]>;
  getStock(symbol: string): Promise<Stock | undefined>;
  getFilteredStocks(filters: StockScreenerFilters): Promise<Stock[]>;
  updateStock(symbol: string, data: Partial<Stock>): Promise<Stock | undefined>;
  createStock(stock: InsertStock): Promise<Stock>;

  // Portfolio methods
  getPortfolio(userId: string): Promise<Portfolio | undefined>;
  updatePortfolio(userId: string, data: Partial<Portfolio>): Promise<Portfolio | undefined>;
  createPortfolio(portfolio: InsertPortfolio): Promise<Portfolio>;

  // Holding methods
  getHoldings(userId: string): Promise<Holding[]>;
  getHolding(userId: string, stockSymbol: string): Promise<Holding | undefined>;
  updateHolding(userId: string, stockSymbol: string, data: Partial<Holding>): Promise<Holding | undefined>;
  createHolding(holding: InsertHolding): Promise<Holding>;
  deleteHolding(userId: string, stockSymbol: string): Promise<boolean>;

  // Trade methods
  getTrades(userId: string): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;

  // IPO methods
  getIPOs(): Promise<IPO[]>;
  createIPO(ipo: InsertIPO): Promise<IPO>;

  // News methods
  getNews(): Promise<NewsArticle[]>;
  createNewsArticle(article: InsertNewsArticle): Promise<NewsArticle>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private stocks: Map<string, Stock>;
  private portfolios: Map<string, Portfolio>;
  private holdings: Map<string, Holding[]>;
  private trades: Map<string, Trade[]>;
  private ipos: Map<string, IPO>;
  private news: Map<string, NewsArticle>;

  constructor() {
    this.users = new Map();
    this.stocks = new Map();
    this.portfolios = new Map();
    this.holdings = new Map();
    this.trades = new Map();
    this.ipos = new Map();
    this.news = new Map();
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample stocks
    const sampleStocks: Stock[] = [
      {
        id: randomUUID(),
        symbol: 'AAPL',
        name: 'Apple Inc.',
        price: '173.45',
        change: '2.87',
        changePercent: '1.68',
        volume: 48200000,
        marketCap: '$2.73T',
        peRatio: '28.4',
        sector: 'Technology',
        lastUpdated: new Date(),
      },
      {
        id: randomUUID(),
        symbol: 'MSFT',
        name: 'Microsoft Corporation',
        price: '412.78',
        change: '-1.23',
        changePercent: '-0.30',
        volume: 31500000,
        marketCap: '$3.06T',
        peRatio: '35.1',
        sector: 'Technology',
        lastUpdated: new Date(),
      },
      {
        id: randomUUID(),
        symbol: 'GOOGL',
        name: 'Alphabet Inc.',
        price: '178.92',
        change: '4.56',
        changePercent: '2.61',
        volume: 25800000,
        marketCap: '$2.21T',
        peRatio: '24.7',
        sector: 'Technology',
        lastUpdated: new Date(),
      }
    ];

    sampleStocks.forEach(stock => {
      this.stocks.set(stock.symbol, stock);
    });

    // Sample IPOs
    const sampleIPOs: IPO[] = [
      {
        id: randomUUID(),
        symbol: 'ARM',
        name: 'Arm Holdings',
        price: '51.00',
        change: '5.88',
        changePercent: '12.4',
        ipoDate: new Date('2024-09-14'),
        status: 'active',
      },
      {
        id: randomUUID(),
        symbol: 'KKVR',
        name: 'Klaviyo Inc',
        price: '30.00',
        change: '-1.00',
        changePercent: '-3.2',
        ipoDate: new Date('2024-09-21'),
        status: 'active',
      }
    ];

    sampleIPOs.forEach(ipo => {
      this.ipos.set(ipo.id, ipo);
    });

    // Sample news
    const sampleNews: NewsArticle[] = [
      {
        id: randomUUID(),
        title: 'Apple Announces New iPhone Series',
        summary: 'Revolutionary features drive stock price up 2.8% in after-hours trading...',
        source: 'TechNews',
        publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        relatedSymbols: ['AAPL'],
      },
      {
        id: randomUUID(),
        title: 'Fed Signals Rate Cuts',
        summary: 'Market rallies on positive economic outlook and inflation control measures...',
        source: 'FinanceDaily',
        publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
        relatedSymbols: [],
      }
    ];

    sampleNews.forEach(article => {
      this.news.set(article.id, article);
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Stock methods
  async getStocks(): Promise<Stock[]> {
    return Array.from(this.stocks.values());
  }

  async getStock(symbol: string): Promise<Stock | undefined> {
    return this.stocks.get(symbol);
  }

  async getFilteredStocks(filters: StockScreenerFilters): Promise<Stock[]> {
    let stocks = Array.from(this.stocks.values());

    if (filters.sector) {
      stocks = stocks.filter(stock => stock.sector === filters.sector);
    }

    if (filters.minPrice !== undefined) {
      stocks = stocks.filter(stock => parseFloat(stock.price) >= filters.minPrice!);
    }

    if (filters.maxPrice !== undefined) {
      stocks = stocks.filter(stock => parseFloat(stock.price) <= filters.maxPrice!);
    }

    if (filters.minVolume !== undefined) {
      stocks = stocks.filter(stock => stock.volume >= filters.minVolume!);
    }

    // Sort results
    if (filters.sortBy) {
      stocks.sort((a, b) => {
        let aVal: any;
        let bVal: any;

        switch (filters.sortBy) {
          case 'price':
            aVal = parseFloat(a.price);
            bVal = parseFloat(b.price);
            break;
          case 'change':
            aVal = parseFloat(a.change);
            bVal = parseFloat(b.change);
            break;
          case 'volume':
            aVal = a.volume;
            bVal = b.volume;
            break;
          default:
            aVal = a.symbol;
            bVal = b.symbol;
        }

        if (filters.sortOrder === 'desc') {
          return bVal < aVal ? -1 : bVal > aVal ? 1 : 0;
        }
        return aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
      });
    }

    return stocks;
  }

  async updateStock(symbol: string, data: Partial<Stock>): Promise<Stock | undefined> {
    const stock = this.stocks.get(symbol);
    if (!stock) return undefined;

    const updatedStock = { ...stock, ...data, lastUpdated: new Date() };
    this.stocks.set(symbol, updatedStock);
    return updatedStock;
  }

  async createStock(insertStock: InsertStock): Promise<Stock> {
    const id = randomUUID();
    const stock: Stock = { 
      ...insertStock, 
      id, 
      lastUpdated: new Date() 
    };
    this.stocks.set(stock.symbol, stock);
    return stock;
  }

  // Portfolio methods
  async getPortfolio(userId: string): Promise<Portfolio | undefined> {
    return this.portfolios.get(userId);
  }

  async updatePortfolio(userId: string, data: Partial<Portfolio>): Promise<Portfolio | undefined> {
    const portfolio = this.portfolios.get(userId);
    if (!portfolio) return undefined;

    const updatedPortfolio = { ...portfolio, ...data, lastUpdated: new Date() };
    this.portfolios.set(userId, updatedPortfolio);
    return updatedPortfolio;
  }

  async createPortfolio(insertPortfolio: InsertPortfolio): Promise<Portfolio> {
    const id = randomUUID();
    const portfolio: Portfolio = { 
      ...insertPortfolio, 
      id, 
      lastUpdated: new Date() 
    };
    this.portfolios.set(portfolio.userId, portfolio);
    return portfolio;
  }

  // Holding methods
  async getHoldings(userId: string): Promise<Holding[]> {
    return this.holdings.get(userId) || [];
  }

  async getHolding(userId: string, stockSymbol: string): Promise<Holding | undefined> {
    const userHoldings = this.holdings.get(userId) || [];
    return userHoldings.find(h => h.stockSymbol === stockSymbol);
  }

  async updateHolding(userId: string, stockSymbol: string, data: Partial<Holding>): Promise<Holding | undefined> {
    const userHoldings = this.holdings.get(userId) || [];
    const holdingIndex = userHoldings.findIndex(h => h.stockSymbol === stockSymbol);
    
    if (holdingIndex === -1) return undefined;

    const updatedHolding = { ...userHoldings[holdingIndex], ...data };
    userHoldings[holdingIndex] = updatedHolding;
    this.holdings.set(userId, userHoldings);
    return updatedHolding;
  }

  async createHolding(insertHolding: InsertHolding): Promise<Holding> {
    const id = randomUUID();
    const holding: Holding = { ...insertHolding, id };
    
    const userHoldings = this.holdings.get(holding.userId) || [];
    userHoldings.push(holding);
    this.holdings.set(holding.userId, userHoldings);
    return holding;
  }

  async deleteHolding(userId: string, stockSymbol: string): Promise<boolean> {
    const userHoldings = this.holdings.get(userId) || [];
    const filteredHoldings = userHoldings.filter(h => h.stockSymbol !== stockSymbol);
    
    if (filteredHoldings.length === userHoldings.length) return false;
    
    this.holdings.set(userId, filteredHoldings);
    return true;
  }

  // Trade methods
  async getTrades(userId: string): Promise<Trade[]> {
    return this.trades.get(userId) || [];
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const id = randomUUID();
    const trade: Trade = { 
      ...insertTrade, 
      id, 
      status: 'completed',
      timestamp: new Date() 
    };
    
    const userTrades = this.trades.get(trade.userId) || [];
    userTrades.push(trade);
    this.trades.set(trade.userId, userTrades);
    return trade;
  }

  // IPO methods
  async getIPOs(): Promise<IPO[]> {
    return Array.from(this.ipos.values());
  }

  async createIPO(insertIPO: InsertIPO): Promise<IPO> {
    const id = randomUUID();
    const ipo: IPO = { ...insertIPO, id };
    this.ipos.set(id, ipo);
    return ipo;
  }

  // News methods
  async getNews(): Promise<NewsArticle[]> {
    return Array.from(this.news.values())
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
  }

  async createNewsArticle(insertArticle: InsertNewsArticle): Promise<NewsArticle> {
    const id = randomUUID();
    const article: NewsArticle = { ...insertArticle, id };
    this.news.set(id, article);
    return article;
  }
}

export const storage = new MemStorage();
