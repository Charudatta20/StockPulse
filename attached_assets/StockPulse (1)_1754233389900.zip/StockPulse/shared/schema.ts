import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const stocks = pgTable("stocks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  symbol: text("symbol").notNull().unique(),
  name: text("name").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  change: decimal("change", { precision: 10, scale: 2 }).notNull(),
  changePercent: decimal("change_percent", { precision: 5, scale: 2 }).notNull(),
  volume: integer("volume").notNull(),
  marketCap: text("market_cap").notNull(),
  peRatio: decimal("pe_ratio", { precision: 8, scale: 2 }),
  sector: text("sector").notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const portfolios = pgTable("portfolios", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  totalValue: decimal("total_value", { precision: 12, scale: 2 }).notNull(),
  dayChange: decimal("day_change", { precision: 10, scale: 2 }).notNull(),
  dayChangePercent: decimal("day_change_percent", { precision: 5, scale: 2 }).notNull(),
  buyingPower: decimal("buying_power", { precision: 12, scale: 2 }).notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const holdings = pgTable("holdings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  stockSymbol: text("stock_symbol").notNull(),
  shares: integer("shares").notNull(),
  averagePrice: decimal("average_price", { precision: 10, scale: 2 }).notNull(),
  currentValue: decimal("current_value", { precision: 12, scale: 2 }).notNull(),
  totalGainLoss: decimal("total_gain_loss", { precision: 10, scale: 2 }).notNull(),
  totalGainLossPercent: decimal("total_gain_loss_percent", { precision: 5, scale: 2 }).notNull(),
});

export const trades = pgTable("trades", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  stockSymbol: text("stock_symbol").notNull(),
  type: text("type").notNull(), // 'buy' or 'sell'
  shares: integer("shares").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  totalAmount: decimal("total_amount", { precision: 12, scale: 2 }).notNull(),
  orderType: text("order_type").notNull(), // 'market', 'limit', 'stop'
  status: text("status").notNull().default('completed'), // 'pending', 'completed', 'cancelled'
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const ipos = pgTable("ipos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  change: decimal("change", { precision: 10, scale: 2 }).notNull(),
  changePercent: decimal("change_percent", { precision: 5, scale: 2 }).notNull(),
  ipoDate: timestamp("ipo_date").notNull(),
  status: text("status").notNull(), // 'upcoming', 'active', 'closed'
});

export const newsArticles = pgTable("news_articles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  source: text("source").notNull(),
  publishedAt: timestamp("published_at").notNull(),
  relatedSymbols: text("related_symbols").array(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertStockSchema = createInsertSchema(stocks).omit({
  id: true,
  lastUpdated: true,
});

export const insertTradeSchema = createInsertSchema(trades).omit({
  id: true,
  timestamp: true,
  status: true,
});

export const insertHoldingSchema = createInsertSchema(holdings).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Stock = typeof stocks.$inferSelect;
export type InsertStock = z.infer<typeof insertStockSchema>;

export type Portfolio = typeof portfolios.$inferSelect;
export type InsertPortfolio = typeof portfolios.$inferInsert;

export type Holding = typeof holdings.$inferSelect;
export type InsertHolding = z.infer<typeof insertHoldingSchema>;

export type Trade = typeof trades.$inferSelect;
export type InsertTrade = z.infer<typeof insertTradeSchema>;

export type IPO = typeof ipos.$inferSelect;
export type InsertIPO = typeof ipos.$inferInsert;

export type NewsArticle = typeof newsArticles.$inferSelect;
export type InsertNewsArticle = typeof newsArticles.$inferInsert;

// Currency types
export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'INR';

export interface ExchangeRates {
  [key: string]: number;
}

export interface StockScreenerFilters {
  sector?: string;
  marketCap?: string;
  minPrice?: number;
  maxPrice?: number;
  minVolume?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}
